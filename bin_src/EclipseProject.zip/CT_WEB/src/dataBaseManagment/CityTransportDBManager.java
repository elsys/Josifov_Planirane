/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package dataBaseManagment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.DirectedWeightedMultigraph;

import tools.ValueFactorSetter;

import dataStructures.Coords;
import dataStructures.TransportLine;
import dataStructures.TransportStop;
import dataStructures.VerticeData;

/**
 * Uses the CT database
 * 
 * @author George Josifov
 * @see IDataBaseConnector
 */
public class CityTransportDBManager implements IDataBaseConnector {
	// the connector for the database
	private String DRIVER;
	// ip of the db server
	private String url;
	// username on the db server
	private String user;
	// password of the db server
	private String pass;
	// the connection with the database
	private Connection connection;

	/**
	 * 
	 * Constructor that sets all the fields with values, the given values
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * 
	 */
	public CityTransportDBManager(String DRIVER, String url, String user,
			String pass) {

		this.DRIVER = DRIVER;
		this.url = url;
		this.user = user;
		this.pass = pass;
	}

	/**
	 * Creates a connection with the db
	 * 
	 * @see IDataBaseConnector
	 */
	public void connect() throws ClassNotFoundException, SQLException {
		Class.forName(DRIVER);

		this.connection = DriverManager.getConnection(this.url, this.user,
				this.pass);
	}

	/**
	 * Closes a connection with the db
	 * 
	 * @see IDataBaseConnector
	 */
	public void closeConnection() {
		if (this.connection != null)
			try {
				this.connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

	/**
	 * Gets the id of the walking line from the DB
	 * 
	 * @throws throws SQLException , ClassNotFoundException
	 */
	public String getWalkLineId() throws SQLException, ClassNotFoundException {
		String result = "";

		Statement st = this.connection.createStatement();
		ResultSet rs = st
				.executeQuery("SELECT paramName, paramValue FROM Configuration;");

		while (rs.next()) {
			if (rs.getString("paramName").equals("walkLineId"))
				result = rs.getString("paramValue");
		}

		return result;
	}

	/**
	 * Gets all properties of the stops from the db and stores them in a Map in
	 * which the key is the id of the transport stop
	 * 
	 * @return the map of transport stops
	 */
	public Map<String, TransportStop> getAllStops() throws SQLException {
		// Map that will contain the result
		Map<String, TransportStop> result = new HashMap<String, TransportStop>();

		// Gets the data from the db
		Statement st = this.connection.createStatement();
		ResultSet rs = st
				.executeQuery("SELECT idstop, latitude, longitude, name FROM Stops;");

		// For each row in the table:
		while (rs.next()) {
			// If she stop has coordinates written in the database it puts them,
			// otherwise adds null on their place
			if (rs.getString("latitude") != ""
					&& rs.getString("latitude") != null) {
				result.put(rs.getString("idstop"), new TransportStop(rs
						.getString("idstop"), rs.getString("name"), new Coords(
						Double.parseDouble(rs.getString("latitude")), Double
								.parseDouble(rs.getString("longitude")))));
			} else {
				result.put(rs.getString("idstop"), new TransportStop(rs
						.getString("idstop"), rs.getString("name"), null));
			}
		}
		return result;
	}

	/**
	 * Gets all properties of the lines from the db and stores them in a Map in
	 * which the key is the id of the line
	 * 
	 * @return the map of transport lines
	 */

	public Map<String, TransportLine> getAllLines() throws SQLException {
		// Map that will contain the result
		Map<String, TransportLine> result = new HashMap<String, TransportLine>();

		// Gets the data from the db
		Statement st = this.connection.createStatement();
		ResultSet rs = st
				.executeQuery("SELECT idTransport, Transports.name, TransportTypes.name, TransportTypes.imageUrl FROM Transports INNER JOIN TransportTypes ON idType = `type`");

		// For each row in the table:
		while (rs.next()) {
			// Puts the info at the Map
			result.put(rs.getString("idTransport"), new TransportLine(rs
					.getString("idTransport"), rs.getString("Transports.name"),
					rs.getString("TransportTypes.name"), rs
							.getString("TransportTypes.imageUrl")));
		}
		return result;
	}

	/**
	 * Gets the stops and connections(transport lines) between them from the
	 * database and adds them to the graph. This is done by making all the
	 * stops, graph vertices. The connections are realized by adding an
	 * additional vertice for each transport that goes from there and connecting
	 * it to the stop vertice with edge cost the time for waiting that
	 * transport. Additionally these vertices are connected with the
	 * corresponding vertice on the next stop on which the transport mean is
	 * going. The cost of the edge on this connections is the time that takes
	 * the transport mean to get from the first stop to the second.
	 * 
	 * @param g
	 *            the graph which is going to be populated
	 * @param walkLine
	 * 
	 * @return void
	 */
	private void generateStopsAndConnections(
			DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge> g,
			String walkLineId) throws Exception {
		Statement st = this.connection.createStatement();
		// Gets all stops lines and times between them from the database and
		// stores them in a ResultRet
		ResultSet rs = st
				.executeQuery("SELECT type, avgWaitTime,origStop, destStop, line, travelTime FROM Connections INNER JOIN Transports on idTransport = line");

		// For each row in the database:
		while (rs.next()) {
			String from = rs.getString("origStop"); // The outgoing stop
			String to = rs.getString("destStop"); // The incoming stop

			VerticeData sourceCollectiveStop = new VerticeData(from, walkLineId);
			VerticeData destCollectiveStop = new VerticeData(to, walkLineId);

			// if the graph does already contain this stops this methods return
			// false and if not
			// adds them
			g.addVertex(sourceCollectiveStop);
			g.addVertex(destCollectiveStop);

			// If the connection between the stops is walking, creates and edge
			// but its cost is multiplied by 3, because its more uncomfortable
			// for the user than taking a transport mean
			if (rs.getDouble("avgWaitTime") == 0
					&& rs.getString("line").equals(walkLineId)) {
				DefaultWeightedEdge e = g.addEdge(sourceCollectiveStop,
						destCollectiveStop);
				g.setEdgeWeight(e, ValueFactorSetter.stress(rs
						.getInt("travelTime")));
			} else {
				// If the line is a transport mean (and not walking) creates two
				// new objects that are going to represent noncollective
				// vertices
				VerticeData origName = new VerticeData(from, rs
						.getString("line"));
				VerticeData destName = new VerticeData(to, rs.getString("line"));

				// If the graph douesn't contains them already adds them
				if (!g.containsVertex(origName))
					g.addVertex(origName);
				if (!g.containsVertex(destName))
					g.addVertex(destName);

				// Creates the connection between the collective stop and the
				// noncollective stop and adds the time for waiting the given
				// transport a default value
				DefaultWeightedEdge e = g.addEdge(sourceCollectiveStop,
						origName);
				g.setEdgeWeight(e, rs.getInt("avgWaitTime"));

				// The time for getting in the transport mean is null
				e = g.addEdge(destName, destCollectiveStop);
				g.setEdgeWeight(e, 0);

				// Connects the two stops with the transport and sets the time
				e = g.addEdge(origName, destName);
				g.setEdgeWeight(e, rs.getInt("travelTime"));
			}
		}
	}

	/**
	 * Populates the graph using generateStopsAndConnections() and prints the
	 * time used for this
	 * 
	 * @param walkLine
	 * 
	 * @throws Exception
	 * @return populated graph
	 */
	public DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge> populateGraphFromDB(
			String walkLineId) throws Exception {
		System.out.println("Populating the graph...");
		long startTime = System.currentTimeMillis(); // / time stamp

		// Creates the graph on which all calculations will be made
		DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge> g = new DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge>(
				DefaultWeightedEdge.class);

		generateStopsAndConnections(g, walkLineId); // Populates the graph

		// Printing time stamp:
		double stopTime = (System.currentTimeMillis() - startTime) / 1000.0;

		System.out.println("Graph ready in " + stopTime + " sec");
		System.out.println("Graph contains " + g.vertexSet().size()
				+ " vertices and " + g.edgeSet().size() + " edges.");

		return g; // returns the graph
	}
	
	
	/**
	 * Returns a statement for custom sql queries
	 * 
	 */
	public Statement getStatement() throws SQLException {
		return connection.createStatement();
	}
}
