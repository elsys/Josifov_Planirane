/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package dataStructures;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents the link between two stops traveled without changing transport
 * 
 * @author George Josifov
 * 
 */
public class TravelContent {
	// The stop from which the user should get\change
	// transport mean, or the destination stop
	TransportStop transferStop;

	// The time between two stop which are either start,
	// final or stop in which the user is descending
	double travelTime;

	// The lines that are common
	// for this and the next
	// transferStop stop
	Set<TransportLine> lines = new HashSet<TransportLine>();

	// The stops that the
	// people travel
	// with the same
	// transport
	List<TransportStop> transitStops = new ArrayList<TransportStop>();

	/**
	 * Default constructor
	 */
	public TravelContent() {
	};

	/**
	 * Constructor
	 */
	public TravelContent(TransportStop transferStop, double travelTime,
			Set<TransportLine> lines, List<TransportStop> transitStops) {
		this.transferStop = transferStop;
		this.travelTime = travelTime;
		this.lines = lines;
		this.transitStops = transitStops;
	};

	/**
	 * @return the transferStop
	 */
	public TransportStop getTransferStop() {
		return transferStop;
	}

	/**
	 * @param transferStop
	 *            the transferStop to set
	 */
	public void setTransferStop(TransportStop transferStop) {
		this.transferStop = transferStop;
	}

	/**
	 * @return the travelTime
	 */
	public double getTravelTime() {
		return travelTime;
	}

	/**
	 * @param travelTime
	 *            the travelTime to set
	 */
	public void setTravelTime(double travelTime) {
		this.travelTime = travelTime;
	}

	/**
	 * @return the lines
	 */
	public Set<TransportLine> getLines() {
		return lines;
	}

	/**
	 * @param lines
	 *            the lines to set
	 */
	public void setLines(Set<TransportLine> lines) {
		this.lines = lines;
	}

	/**
	 * @return the transitStops
	 */
	public List<TransportStop> getTransitStops() {
		return transitStops;
	}

	/**
	 * @param transitStops
	 *            the transitStops to set
	 */
	public void setTransitStops(List<TransportStop> transitStops) {
		this.transitStops = transitStops;
	}

	/**
	 * 
	 * @param s
	 *            the string to add in transitStops
	 * @param index
	 *            where to add the string
	 */
	public void addTransitStop(int index, TransportStop s) {
		this.transitStops.add(index, s);
	}

}
