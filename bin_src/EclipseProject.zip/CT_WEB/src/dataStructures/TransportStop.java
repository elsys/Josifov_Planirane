/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package dataStructures;


/**
 * Contains the name, id and coordinates of a stop
 *  
 * @author George Josifov
 *
 */
public class TransportStop {
	// The id of the stop in the db 
	String id;
	// The name of the stop
	String name;
	// The coordinates of the stop
	Coords coord;

	
	/**
	 * Default constructor
	 */
	public TransportStop(){
		
	}
	
	/**
	 * Constructor
	 */
	public TransportStop(String id, String name, Coords coord){
		this.id = id;
		this.name = name;
		this.coord = coord;
		
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the coord
	 */
	public Coords getCoord() {
		return coord;
	}

	/**
	 * @param coord the coord to set
	 */
	public void setCoord(Coords coord) {
		this.coord = coord;
	}
}
