/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package dataStructures;

/**
 * Data object, that contains stop id and one transport line associated with it,
 * used for vertice in the graph
 * 
 * @author George Josifov
 * 
 */
public class VerticeData {
	private String stopName; // The stop id
	private String line; // The transport mean associated with this vertice

	/**
	 * Default Constructor
	 * 
	 */
	public VerticeData() {

	}

	/**
	 * Constructor 
	 * 
	 * @param stopName
	 * @param line
	 */
	public VerticeData(String stopName, String line) {
		this.stopName = stopName;
		this.line = line;
	}

	/**
	 * Returns the transport associated with this stop
	 * 
	 * @return the transport mean associated with this vertice
	 */
	public String getLine() {
		return line;
	}

	/**
	 * Sets the transport mean associated with this vertice
	 * 
	 * @return void
	 */
	public void setLine(String line) {
		this.line = line;
	}

	/**
	 * Returns the name of the stop in this vertice
	 * 
	 * @return the name the the stop
	 */
	public String getStopName() {
		return stopName;
	}

	/**
	 * Sets the name of the stop in this vertice
	 * 
	 * @return void
	 */
	public void setStopName(String stopName) {
		this.stopName = stopName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 21;
		int result = 1;
		result = prime * result + ((line == null) ? 0 : line.hashCode());
		result = prime * result
				+ ((stopName == null) ? 0 : stopName.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VerticeData other = (VerticeData) obj;
		if (line == null) {
			if (other.line != null)
				return false;
		} else if (!line.equals(other.line))
			return false;
		if (stopName == null) {
			if (other.stopName != null)
				return false;
		} else if (!stopName.equals(other.stopName))
			return false;
		return true;
	}

}
