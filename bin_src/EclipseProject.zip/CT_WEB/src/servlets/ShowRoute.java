/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dataStructures.Coords;
import dataStructures.TransportLine;
import dataStructures.TransportStop;
import dataStructures.TravelContent;
import exceptions.OutsideSystemCoverageException;

import tools.ConfigurationLoader;
import tools.PathFinder;

/**
 * Servlet implementation class ShowRoute
 */
public class ShowRoute extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int WALK_LINE_ID = 123;
	private PathFinder pf;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowRoute() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void init(ServletConfig config) throws ServletException {
		try {
			// Gets the properties form the configuration file
			Properties p = new ConfigurationLoader(config.getServletContext())
					.getConfiguration();

			// Creates new PathFinder which is later used to return the path
			// between two points
			pf = new PathFinder(Double.parseDouble(p.getProperty("MAX_TIME")),
					Double.parseDouble(p.getProperty("WALKING_SPEED")), p
							.getProperty("dbDriver"), p.getProperty("dbName"),
					p.getProperty("dbUser"), p.getProperty("dbPass"));

		} catch (Exception e) { // Unexpected error appeared must close the
			// application
			System.err
					.println("Work cannot continue due initialization error!");
			e.printStackTrace();
			System.exit(-1);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		Coords startStopCoords = new Coords(Double.parseDouble(request
				.getParameter("startLat")), Double.parseDouble(request
				.getParameter("startLon")));
		Coords finalStopCoords = new Coords(Double.parseDouble(request
				.getParameter("endLat")), Double.parseDouble(request
				.getParameter("endLon")));
		response.setCharacterEncoding("UTF-8"); 
		response.setContentType("text/html");
		PrintWriter output = response.getWriter();
		output.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
		output.println("<html>");
		output.println("<head>");
		output.println("<meta http-equiv=\"Content-type\" content=\"text/html;charset=UTF-8\">");
		output.println("<title>Вашият маршрут</title>");
		output.println("</head>");
		output.println("<body>");

		try {
			List<TravelContent> path = pf.getPath(startStopCoords,
					finalStopCoords);
			
			TravelContent prevContent = null;
			for (TravelContent travelCon : path) {
				StringBuilder linesInfo = new StringBuilder();
				boolean walkConnection = false;
				if(travelCon.getTransferStop().getId().compareTo("firstStop") == 0) {
					output.print("Тръгване от: ");
				}
				else 
				{
					
					if(prevContent  != null){
						for(TransportLine line: prevContent.getLines())
						{
							if(Integer.parseInt(line.getId()) == WALK_LINE_ID){
								walkConnection = true;
								break;
							}
							linesInfo.append(" - ");
							linesInfo.append(line.getType());
							linesInfo.append(" ");
							linesInfo.append(line.getName());
							linesInfo.append("<br>");
						}
					}
					if(walkConnection) output.print("Отидете до: ");
					else output.print("Пътуване до: ");
					
				}
				if(travelCon.getTransferStop().getId().compareTo("firstStop") == 0) output.print(request.getParameter("start"));
				else if (travelCon.getTransferStop().getId().compareTo("lastStop") == 0) output.print(request.getParameter("end"));
				else output.println(travelCon.getTransferStop().getName());
				output.println("<br>");
				output.println(linesInfo.toString());
				output.print("<img src=\"http://maps.google.com/maps/api/staticmap?markers=");
				output.print(getCommaSeparatedCoords(travelCon.getTransferStop()));
				
				if(prevContent  != null){
					output.print("|");
					output.print(getCommaSeparatedCoords(prevContent.getTransferStop()));
					output.print("&amp;path=");
					if(walkConnection)
					{
						output.print(getCommaSeparatedCoords(travelCon.getTransferStop()));
						output.print("|");
						output.print(getCommaSeparatedCoords(prevContent.getTransferStop()));
					}
					else
					{
						boolean first = true;
						for(TransportStop transitStop: prevContent.getTransitStops())
						{
							if(transitStop.getCoord() != null)
							{
								if(first) first = false;
								else output.print("|");
								output.print(getCommaSeparatedCoords(transitStop));
							}
						}
					}
				}

				
				output.println("&amp;size=200x200&amp;sensor=false\" alt=\"Route point\">");
				output.println("<br>");
				prevContent = travelCon;
			}
		} catch (OutsideSystemCoverageException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			output.println("Избраните точки за извън покритието на системата");
		}
		output.println("</body></html>");
	}

	private String getCommaSeparatedCoords(TransportStop stop) {
		if(stop!=null && stop.getCoord() != null)
		{
			StringBuilder result = new StringBuilder();
			result.append(stop.getCoord().getLat());
			result.append(",");
			result.append(stop.getCoord().getLon());
			return result.toString();
		}
		else return null;
	}

}
