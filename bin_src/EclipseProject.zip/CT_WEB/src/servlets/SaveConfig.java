/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dataBaseManagment.CityTransportDBManager;

import tools.ConfigurationLoader;
import org.apache.commons.io.IOUtils;


/**
 * Servlet implementation class SaveConfig
 */
public class SaveConfig extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveConfig() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8"); //Set encoding to UTF-8
		
		PrintWriter output = response.getWriter();
		output.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">");
		output.println("<html>");
		output.println("<head>");
		output.println("<meta http-equiv=\"Content-type\" content=\"text/html;charset=UTF-8\">");
		output.println("<title>Public transport - Initial Configuration</title>");
		output.println("</head>");
		output.println("<body>");
		
		ConfigurationLoader configLoader = new ConfigurationLoader(getServletContext()); //Configuration file writer

		if(configLoader.isFilePresent()) { 
			output.println("Конфигурацията вече съществува"); //IF file is present, do nothing
		}
		else
		{
			//Post parameters
			String dbUsername = request.getParameter("dbuser");
			String dbPassword = request.getParameter("dbpass");
			String dbServer = "jdbc:mysql://" + request.getParameter("dbserver") + "/" +  request.getParameter("dbname") + "?useUnicode=true&characterEncoding=UTF-8&autoReconnect=true";
			String driver  = "com.mysql.jdbc.Driver"; //MySQL driver is the only choice for now
			
			try {
				//Try to connect to database
				CityTransportDBManager dbManager = new CityTransportDBManager(driver, dbServer + "&allowMultiQueries=true", dbUsername, dbPassword);
				dbManager.connect();
				
				//Create tables, add information
				Statement st = dbManager.getStatement();
				executeSQLFile("/WEB-INF/BasicTables.sql", st);
				executeSQLFile("/WEB-INF/Stops.sql", st);
				executeSQLFile("/WEB-INF/Transports.sql", st);
				executeSQLFile("/WEB-INF/Connections.sql", st);
				executeSQLFile("/WEB-INF/TriggersFunctions.sql", st);
				
				//Prepare the properites for writing
				Properties p =  new Properties();
				p.setProperty("dbDriver", driver);
				p.setProperty("dbName", dbServer);
				p.setProperty("dbUser", dbUsername);
				p.setProperty("dbPass", dbPassword);
				p.setProperty("WALKING_SPEED", "4.0");
				p.setProperty("MAX_TIME", "10.0");
				configLoader.setConfiguration(p); //Write to file
				
				output.println("Конфигурацията е записана. Отворете <a href='index.jsp'>сайтът</a>"); //Everything in OK
			} catch (SQLException e) {
				//ON database error
				output.println("Не може да се осъществи връзка с базата данни със зададенити параметри. Моля, върнете се обратно и опитайте отново");
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				//If mysql driver is missig
				e.printStackTrace();
			}
			finally
			{
				output.println("</body>");
				output.println("</html>");
			}

		}
		
	}
	public void executeSQLFile(String file, Statement st) throws IOException, SQLException
	{

		InputStream in = getServletContext().getResourceAsStream(file);
		String query = IOUtils.toString(in, "UTF-8");
	    st.execute(query);
	}
}
