/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tools.ConfigurationLoader;
import tools.DegreeCoordCalc;
import tools.PathFinder;

import dataStructures.Coords;
import dataStructures.VerticeData;
import errorHandler.ErrorPrinter;
import exceptions.OutsideSystemCoverageException;

/**
 * Servlet implementation class CT_SetCoordinatesPathServlet
 * 
 * @author George Josifov
 * @see ErrorPrinter
 * @see VerticeData
 * @see DegreeCoordCalc
 * 
 */

public class CT_SetCoordinatesPathServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// Finds path between points
	private PathFinder pf;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CT_SetCoordinatesPathServlet() {
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		try {
			// Gets the properties form the configuration file
			Properties p = new ConfigurationLoader(config.getServletContext())
					.getConfiguration();
			
			// Creates new PathFinder which is later used to return the path between two points
			pf = new PathFinder(Double.parseDouble(p.getProperty("MAX_TIME")),
					Double.parseDouble(p.getProperty("WALKING_SPEED")), p
							.getProperty("dbDriver"), p.getProperty("dbName"),
					p.getProperty("dbUser"), p.getProperty("dbPass"));

		} catch (Exception e) { // Unexpected error appeared must close the application
			System.err
					.println("Work cannot continue due initialization error!");
			e.printStackTrace();
			System.exit(-1);
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response) Prints the shortest path. Uses for input the latitude and
	 *      longitude of two points from the map.
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		// Used to print errors to the user
		ErrorPrinter err = new ErrorPrinter();

		// Gets the data from the form
		String lat1 = request.getParameter("lat1");
		String lon1 = request.getParameter("lon1");
		String lat2 = request.getParameter("lat2");
		String lon2 = request.getParameter("lon2");

		// Checks for blank fields or unexpected errors
		if (((lat1 == "") || (lon1 == "") || (lat2 == "" || lon2 == "")
				|| (lat1 == null) || (lon1 == null) || (lat2 == null) || (lon2 == null))
				|| ((lat1.equals(lat2)) && (lon1.equals(lon2)))) {
			err.PrintError(out, "Моля въведете и начална и крайна спирка!");
		} else {
			try {
				// Parses the latitudes and longitudes to digits and makes
				// Coords objects from them
				Coords startStopCoords = new Coords(Double.parseDouble(lat1),
						Double.parseDouble(lon1));
				Coords finalStopCoords = new Coords(Double.parseDouble(lat2),
						Double.parseDouble(lon2));
				
				// Prints the path between the choosen points
				out.println(pf.getPathToJSON(pf.getPath(startStopCoords,
						finalStopCoords)));
				
				
			} catch (OutsideSystemCoverageException e) {
				// If the points are outside the coverage of the system
				e.printStackTrace();
				err.PrintError(out,
						"Избраните точки са извън покритието на системата!");
			} catch (Exception e) {
				e.printStackTrace();
				err.PrintError(out, "Моля, опитайте по-късно!");
			}
		}
		out.close();
	}
}
