/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package tools;

/**
 * Sets and removes a coefficient used for the walk lines. This is important
 * because it is more uncomfortable for the user to walk on foot. Thats why we
 * make it with 3 times bigger factor.
 * 
 * @author George Josifov
 * 
 */
public class ValueFactorSetter {
	private static final double StressFactor = 3;

	/**
	 * Stresses the value by adding it a factor
	 * 
	 * @param value
	 *            the digit to be stressed
	 * @return the new value
	 * 
	 */
	public static double stress(double value) {
		value *= StressFactor;
		return value;
	}

	/**
	 * Relaxes the value by removing the factor
	 * 
	 * @param value
	 *            the digit to be relaxed
	 * @return the new value
	 * 
	 */
	public static double relax(double value) {
		value /= StressFactor;
		return value;
	}


}
