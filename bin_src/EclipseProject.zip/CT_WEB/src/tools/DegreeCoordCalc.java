/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package tools;

import dataStructures.Coords;

/**
 * Useful tools that calculate distance from latitude and longitude and transfer
 * degrees in radians and the opposite
 * 
 * @author George Josifov
 * 
 */
public class DegreeCoordCalc implements IDegRadConverter, IDistanceCalculator {
	/**
	 * Calculates the distance between two stops by given latitude and longitude
	 * 
	 * @param coord1 the coordinates of the first point
	 * @param coord2 the coordinates of the second point
	 * @return the distance in kilometers between two points, calculated from
	 *         latitudes and longitudes
	 */
	public double calculateDistance(Coords coord1, Coords coord2) {
		double dif = coord1.getLon() - coord2.getLon();
		double dist = Math.acos(Math.sin(deg2rad(coord1.getLat()))
				* Math.sin(deg2rad(coord2.getLat())) + Math.cos(deg2rad(coord1.getLat()))
				* Math.cos(deg2rad(coord2.getLat())) * Math.cos(deg2rad(dif)));

		dist = rad2deg(dist) * 111.18957696;

		return (dist);
	}

	/**
	 * @param deg
	 *            the degrees to transform in radians
	 * @return the degree in radians
	 */
	public double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	/**
	 * @param rad
	 *            the radian to transform in degrees
	 * @return the radian in degrees
	 */
	public double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}
}
