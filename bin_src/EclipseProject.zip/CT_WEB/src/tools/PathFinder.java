/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package tools;

import java.util.List;
import java.util.Map;

import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.DirectedWeightedMultigraph;

import com.google.gson.Gson;

import dataBaseManagment.CityTransportDBManager;
import dataStructures.Coords;
import dataStructures.TransportLine;
import dataStructures.TransportStop;
import dataStructures.TravelContent;
import dataStructures.VerticeData;
import exceptions.OutsideSystemCoverageException;

/**
 * Class that is used to find paths between points defined by their coordinates
 * 
 */
public class PathFinder {
	// Assures that the shared graph will be changed by only one user at any
	// time
	private String mutex = "";

	private Map<String, TransportStop> stopsMap;
	private Map<String, TransportLine> linesMap;

	// Walking speed in km/h
	private Double WALKING_SPEED;

	// The id of the walk line
	private String WALK_LINE_ID;

	// Maximum walking time in minutes
	private Double MAX_TIME;

	// Maximum distance that can be covered in MAX_TIME with WALKING_SPEED
	private Double MAX_DISTANCE;

	// The graph on which all calculations will be made
	private DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge> graph;

	// db manager instance
	private CityTransportDBManager db;

	NearestStopsFinder nearestStopsFinder;

	/**
	 * Constructor
	 * 
	 */
	public PathFinder(Double MAX_TIME, Double WALKING_SPEED, String dbDriver,
			String dbName, String dbUser, String dbPass) {

		this.MAX_TIME = MAX_TIME;
		this.WALKING_SPEED = WALKING_SPEED;
		this.MAX_DISTANCE = this.WALKING_SPEED * this.MAX_TIME / 60.0;

		this.db = new CityTransportDBManager(dbDriver, dbName, dbUser, dbPass);

		System.out.println("Connects to database...");
		try {
			this.db.connect();

			WALK_LINE_ID = db.getWalkLineId();

			this.graph = this.createGraphFromDB(WALK_LINE_ID);
			this.stopsMap = db.getAllStops();
			this.linesMap = db.getAllLines();
		} catch (Exception e) { // Unexpected error appeared must close the
			// application
			System.err
					.println("Work cannot continue due initialization error!");
			e.printStackTrace();
			System.exit(1);
		}

		db.closeConnection();

		this.nearestStopsFinder = new NearestStopsFinder(WALKING_SPEED,
				MAX_DISTANCE);
	}

	/**
	 * Populates the graph from the db.
	 * 
	 * @throws Exception
	 * 
	 * @see CityTransportDBManager
	 * @return populated graph
	 */
	private DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge> createGraphFromDB(
			String walkLineId) throws Exception {
		return this.db.populateGraphFromDB(walkLineId);
	}

	/**
	 * Returns the path between two stops
	 * 
	 * @throws OutsideSystemCoverageException
	 * 
	 * @param startStopCoords
	 *            the coordinates of the starting point
	 * @param finalStopCoords
	 *            the coordinates of the ending point
	 * 
	 * @see CityTransportDBManager
	 * @return The path between the two stops
	 */
	public List<TravelContent> getPath(Coords startStopCoords,
			Coords finalStopCoords) throws OutsideSystemCoverageException {
		// Will contain the path
		List<TravelContent> result;

		// Gets the nearby transport stops to the source and
		// destination
		Map<String, Double> firstStopNeaighbours = nearestStopsFinder
				.getNearbyStops(startStopCoords, stopsMap);
		Map<String, Double> lastStopNeaighbours = nearestStopsFinder
				.getNearbyStops(finalStopCoords, stopsMap);

		// If the distance between the two destinations is small
		// enough (smaller that MAX_DISTANCE) to be taken by
		// walk
		// the value is true
		Boolean nearToWalkTo = false;

		// Finds the distance between the choices
		DegreeCoordCalc calc = new DegreeCoordCalc();
		Double distance = calc.calculateDistance(startStopCoords,
				finalStopCoords);

		// Creates two new vertices that represent the start and
		// final destination
		VerticeData firstStop = new VerticeData("firstStop", WALK_LINE_ID);
		VerticeData lastStop = new VerticeData("laststop", WALK_LINE_ID);

		// Starts the mutex where the graph needs to be changed
		synchronized (mutex) {
			// Adds them to the graph
			graph.addVertex(firstStop);
			graph.addVertex(lastStop);

			// Checks if the two choices are close enough
			if (distance <= MAX_DISTANCE) {
				nearToWalkTo = true;

				// Creates a connection between them with weight the
				// time needed to take the distance on foot
				graph.setEdgeWeight(graph.addEdge(firstStop, lastStop), Math
						.ceil(distance / WALKING_SPEED * 60));
			}

			// If there are no nearby stops and the choices arn't close
			// enough to be walked on foot prints error message
			if ((firstStopNeaighbours.keySet().isEmpty() || lastStopNeaighbours
					.keySet().isEmpty())
					&& !nearToWalkTo) {
				throw new OutsideSystemCoverageException();
			} else {

				// Creates the connections between the source and
				// destinations and their nearby transport stops
				for (String stop : firstStopNeaighbours.keySet()) {
					DefaultWeightedEdge e = this.graph.addEdge(firstStop,
							new VerticeData(stop, WALK_LINE_ID));
					graph.setEdgeWeight(e, firstStopNeaighbours.get(stop));
				}

				for (String stop : lastStopNeaighbours.keySet()) {
					DefaultWeightedEdge e = this.graph.addEdge(new VerticeData(
							stop, WALK_LINE_ID), lastStop);
					graph.setEdgeWeight(e, lastStopNeaighbours.get(stop));
				}

				// Gets the path
				result = new GraphManeger(stopsMap, linesMap,
						new TransportStop("firstStop", "", startStopCoords),
						new TransportStop("lastStop", "", finalStopCoords),
						WALK_LINE_ID).getParsedPath(graph, firstStop, lastStop);

				// Removes the temporary vertices
				graph.removeVertex(firstStop);
				graph.removeVertex(lastStop);
			}
		} // Ends the mutex

		// returns the path
		return result;
	}

	/**
	 * Returns the path between two stops with JSON syntax
	 * 
	 * @param list
	 *            The path to be turned into JSON
	 * 
	 * @see Gson
	 * @return The path between two stops with JSON syntax
	 */
	public String getPathToJSON(List<TravelContent> list) {
		Gson gson = new Gson();
		// Transforms it to JSON and returns it
		return gson.toJson(list);
	}

}
