/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package tools;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jgrapht.alg.BellmanFordShortestPath;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.DirectedWeightedMultigraph;


import dataStructures.TransportLine;
import dataStructures.TransportStop;
import dataStructures.TravelContent;
import dataStructures.VerticeData;

/**
 * Finds and returns the shortest path in the graph with given source and
 * destination
 * 
 * @author George Josifov
 * @see TravelContent
 * @see VerticeData
 */
public class GraphManeger {
	// Creates set that is going to be used when there is "on foot" connection
	// between two stops
	private final Set<TransportLine> walkSet;

	// Keeps reference of map with key the id of the stop in the database and
	// value - all properties of that stop
	private Map<String, TransportStop> stopsMap;

	// Keeps reference of map with key the id of the line in the database and
	// value - all properties of that line
	private Map<String, TransportLine> linesMap;

	// If the first stop is chosen by clicking on the map this contains the
	// coordinates
	private TransportStop fisrtChosenfromMapStop;

	// If the last stop is chosen by clicking on the map this contains the
	// coordinates
	private TransportStop finalChosenfromMapStop;
	
	// The id of the walk line
	private String WALK_LINE_ID;

	/**
	 * Constructor that creates the reference of the stop and line maps and if
	 * the points are chosen from the map sets them non null value, but id and
	 * coordinates
	 * 
	 * @param stopsMap
	 *            the map of stop ids and stops
	 * @param linesMap
	 *            the map of line ids and lines
	 * @param fisrtChosenfromMapStop
	 *            if there is some it contains some id and the coordinates of
	 *            the point. Otherwise it is null pointer.
	 * @param finalChosenfromMapStop
	 *            if there is some it contains some id and the coordinates of
	 *            the point. Otherwise it is null pointer.
	 */
	public GraphManeger(Map<String, TransportStop> stopsMap,
			Map<String, TransportLine> linesMap,
			TransportStop fisrtChosenfromMapStop,
			TransportStop finalChosenfromMapStop, String WALK_LINE_ID) {
		this.walkSet = new HashSet<TransportLine>();

		this.stopsMap = stopsMap;
		this.linesMap = linesMap;
		this.WALK_LINE_ID = WALK_LINE_ID;

		this.walkSet.add(linesMap.get(WALK_LINE_ID));

		this.fisrtChosenfromMapStop = fisrtChosenfromMapStop;
		this.finalChosenfromMapStop = finalChosenfromMapStop;
	}

	/**
	 * Checks if the vertice is a collective one. In other words if there is no
	 * transport associated with it(on foot only), but it is connected with noncollective
	 * vertices with the same stop id, but associated with some transport
	 * 
	 * @param stop
	 *            the vertice which is going to be checked
	 * @return if the vertice is collective
	 */
	private boolean isCollectiveVertice(VerticeData stop) {
		return stop.getLine().equals(WALK_LINE_ID);
	}

	/**
	 * Finds all transports means that stop on given stop
	 * 
	 * @param g
	 *            the graph from which the info is going to be get
	 * @param stop
	 *            the stop whose transport lines we want
	 * @return all transports means that stop on given stop
	 */
	private Set<TransportLine> getAllTransportOnStop(
			DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge> g,
			VerticeData stop) {
		Set<TransportLine> lines = new HashSet<TransportLine>();
		for (DefaultWeightedEdge e : g.outgoingEdgesOf(stop)) {

			if (g.getEdgeTarget(e).getLine() != WALK_LINE_ID) {
				TransportLine line = linesMap.get(g.getEdgeTarget(e).getLine());
				lines.add(line);
			}
		}
		return lines;
	}

	/**
	 * Returns the path between two stops with normalized times. Normal time is
	 * the time that is needed to get to the next transfer stop, and not the
	 * collective time to this one like it is by far.
	 * 
	 * @param content
	 *            the path which times we want to normalize
	 * 
	 * @return The path with normalized times
	 */
	private List<TravelContent> normalizeTimes(List<TravelContent> content) {
		// the collective time of the last stop
		double lastTime = content.get(content.size() - 1).getTravelTime();

		for (int i = content.size() - 1; i > 0; i--) {
			double currentTime = content.get(i - 1).getTravelTime();
			// If it is walking time it removes the factor given in the graf
			if (content.get(i - 1).getLines().containsAll(walkSet)) {
				content.get(i).setTravelTime(
						Math.ceil(ValueFactorSetter.relax(lastTime
								- currentTime)));
			} else {
				content.get(i).setTravelTime(lastTime - currentTime);
			}
			lastTime = currentTime;
		}

		return content;
	}

	/**
	 * Gets the fastest path and parses it in useful way.
	 * 
	 * @param g
	 *            the graph on which the shortest path algorithm will be run
	 * @param start
	 *            the start point in the path
	 * @param finish
	 *            the end point of the path
	 * 
	 * @return List of travelContent that make the path
	 */
	public List<TravelContent> getParsedPath(
			DirectedWeightedMultigraph<VerticeData, DefaultWeightedEdge> g,
			VerticeData start, VerticeData finish) {

		// indicates if the path is chosen by clicking on the map. In that case
		// the values of
		// fisrtChosenfromMapStop and finalChosenfromMapStop should be non null
		boolean isChoiseFromTheMap = (fisrtChosenfromMapStop != null || finalChosenfromMapStop != null);

		// the list that is going to contain the path and all its additional
		// info
		List<TravelContent> resultList = new ArrayList<TravelContent>();

		try {
			// Creates instance of the shortest path calculator
			BellmanFordShortestPath<VerticeData, DefaultWeightedEdge> bf = new BellmanFordShortestPath<VerticeData, DefaultWeightedEdge>(
					g, start);

			// Gets the path
			List<DefaultWeightedEdge> path = bf.getPathEdgeList(finish);

			// Uses it later to populate the resultList
			TravelContent content = null;

			// Represents firstly the last element of the resultList and then
			// the next. This is needed for the algorithm to find the mutual
			// transport means on the previous and next transfer stop.
			TravelContent nextContent = new TravelContent();

			// if the final\start points aren't chosen from the map it sets the
			// stop that response to the id of the final stop and makes it the
			// last transfer stop in the list
			if (!isChoiseFromTheMap) {
				nextContent.setTransferStop(stopsMap.get(finish.getStopName()));
			} else {
				// if chosen from the map it simply sets the
				// finalChosenfromMapStop (that contains the coordinates and
				// some id) as last transport stop
				nextContent.setTransferStop(finalChosenfromMapStop);
			}
			// Sets the travel time to the final stop
			nextContent.setTravelTime(bf.getCost(finish));

			// Shows if the previous vertice was collective. In other words if
			// the last checked stop was transfer stop.
			boolean prevVrtcWasCollective = true;

			// Reads every element form the path backwards so that it can
			// compare the transport lines from the next and the current and
			// write
			// them. At first for the next element is considered the final stop.
			// By this mean the transportElements are going to be put at the
			// beginning at the resultList.
			for (int i = (path.size() - 1); i >= 0; i--) {
				// The content is going to be null every time we go to other
				// TransportContent. If it is that mean that all the info for
				// the previous is stored and we create a new one.
				if (content == null) {
					content = new TravelContent();
				}

				// Gets the source stop from the next edge of the path
				VerticeData stop = g.getEdgeSource(path.get(i));

				// If the vertice is collective(if the people have to change
				// transport or get down/up a transport mean)
				if (isCollectiveVertice(stop)) {
					// Adds in the resultList the next travelContent
					resultList.add(0, nextContent);

					// Sets the transferStop on the current travelContent with
					// the representing stop in the stopMap
					content.setTransferStop(stopsMap.get(stop.getStopName()));

					// if the previous vertice wasn't also collective then the
					// lines between the stops are determined by intercepting
					// the lists of lines on the next stop and the current one
					if (!prevVrtcWasCollective) {
						Set<TransportLine> lines = getAllTransportOnStop(g,
								stop);
						lines.retainAll(getAllTransportOnStop(g,
								new VerticeData(nextContent.getTransferStop()
										.getId(), WALK_LINE_ID)));
						content.setLines(lines);

						// Tells that the last vertice was collective
						prevVrtcWasCollective = true;
					} else {
						// If the previous vertice was also collective that
						// means that they are connected without transport mean,
						// but by "on foot" transport
						content.setLines(this.walkSet);
					}
					// Sets the time needed to get to this stop
					try {
						content.setTravelTime(bf.getCost(stop));
					} catch (Exception e) {
						// Throws exception at the first stop
					}
					// This TransportContent becomes the next
					nextContent = content;
					// Clears the current content
					content = null;

				} else {
					// If the stop isn't collective that means that it is
					// transitStop. In other words stop, that the people should
					// travel with the same transport
					content.addTransitStop(0, stopsMap.get(stop.getStopName()));

					if (prevVrtcWasCollective) {
						// Tells that this vertice wasn't collective
						prevVrtcWasCollective = false;
					}
				}
			}
			if (isChoiseFromTheMap) {
				// If the begin/end points were chosen by clicking on the map
				// sets the first transferStop with the clicked one
				nextContent.setTransferStop(fisrtChosenfromMapStop);
			}
			// Adds it to the list
			resultList.add(0, nextContent);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("oops.. something went wrong");
		}
		return normalizeTimes(resultList);
	}

}
