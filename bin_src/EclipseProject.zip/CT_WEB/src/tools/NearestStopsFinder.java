/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package tools;


import java.util.HashMap;
import java.util.Map;

import dataStructures.Coords;
import dataStructures.TransportStop;

/**
 * Finds all nearby stops to point with some given coordinates
 * 
 * @author George Josifov
 * 
 */
public class NearestStopsFinder {
	// Walking speed in km/h
	private Double WALKING_SPEED;

	// Maximum distance that can be covered in
	// MAX_TIME with WALKING_SPEED
	private Double MAX_DISTANCE;

	/**
	 * 
	 * Constructor
	 * 
	 */
	public NearestStopsFinder(Double WALKING_SPEED, Double MAX_DISTANCE) {
		this.MAX_DISTANCE = MAX_DISTANCE;
		this.WALKING_SPEED = WALKING_SPEED;
	}

	/**
	 * Finds all nearest stops and calculates the time that takes to go to them
	 * 
	 * @param stopCoords
	 *            the coordinates of the point near which we search the stops
	 * @param fromStops
	 *            the stops from which we get the nearby ones
	 * @return map, in witch the key is id of near stop and the value is the
	 *         time needed to get there by walking
	 */
	public Map<String, Double> getNearbyStops(Coords stopCoords,
			Map<String, TransportStop> fromStops) {
		// the Map that is going to contain the Stops and the time to them
		Map<String, Double> result = new HashMap<String, Double>();

		// calculates the boundaries in witch is going to be searched for near
		// stops
		DegreeCoordCalc calc = new DegreeCoordCalc();
		double minLon = stopCoords.getLon() - MAX_DISTANCE
				/ Math.abs(Math.cos(calc.deg2rad(stopCoords.getLat())) * 111);
		double maxLon = stopCoords.getLon() + MAX_DISTANCE
				/ Math.abs(Math.cos(calc.deg2rad(stopCoords.getLat())) * 111);

		double minLat = stopCoords.getLat() - MAX_DISTANCE / 111;
		double maxLat = stopCoords.getLat() + MAX_DISTANCE / 111;

		// gets the stops in this boundaries

		for (String k : fromStops.keySet()) {
			Coords coords = fromStops.get(k).getCoord();
			if (coords != null)
				if (coords.getLat() < maxLat && coords.getLat() > minLat
						&& coords.getLon() > minLon && coords.getLon() < maxLon) {

					// calculates the distance to the stop
					Double distance = calc
							.calculateDistance(stopCoords, coords);
					if (distance < MAX_DISTANCE) {
						// if the distance is smaller than the maximum allowed
						// distance
						// calculates the time and puts it in the result Map
						Double time = Math.ceil(distance / WALKING_SPEED * 60);

						result.put(k, time);
					}
				}
		}
		return result; // Returns all nearest stops
	}
}
