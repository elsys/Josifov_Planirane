/**
 *  Copyright (C) 2010  George Josifov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package tools;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;

/**
 * Loads the properties file for the servlets and db options
 * 
 * @author George Josifov
 * 
 */
public class ConfigurationLoader {
	private String confFileName = "app.properties";
	private String containingFolder = "/WEB-INF/";
	private ServletContext context;

	
	public ConfigurationLoader(ServletContext context) {
		this.context = context;
	}
	
	public ConfigurationLoader() {
	}
	
	public void setContext(ServletContext context) {
		this.context = context;
	}
	
	/**
	 * Loads properties from .properties file
	 * 
	 * @return the properties
	 */
	public Properties getConfiguration() {
		

		
		Properties p = new Properties();
		try {
			InputStream inputStream = context.getResourceAsStream(containingFolder + confFileName);

			p.load(inputStream);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Connot configure the program!");
			System.exit(0);
		}
		return p;
	}

	public boolean isFilePresent() {
		try {
			return context.getResourceAsStream(containingFolder + confFileName).available() > 0;
		} catch (Exception e) {
			return false;
		}
	}

	public void setConfiguration(Properties p) {

		try {
			p.store(new FileOutputStream(context.getRealPath(
					containingFolder + confFileName)), null);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("Connot configure the properties file!");
			System.exit(0);
		}
	}

}
