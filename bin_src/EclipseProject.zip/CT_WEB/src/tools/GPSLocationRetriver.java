/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package tools;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class GPSLocationRetriver {
	private static final String URL = "http://maps.google.com/maps/api/geocode/xml?address=";
	private static final String URL_SUFFIX = "&bounds=42.62,23.1|42.8,23.5&sensor=false";
	private double startLat, startLon, finishLat, finishLon;
	
	public GPSLocationRetriver(String start, String finish)
	{
		retrieveData(start, true);
		retrieveData(finish, false);
	}
	private void retrieveData(String address, boolean start)
	{
		XPathFactory factory = XPathFactory.newInstance();

	    XPath xpath = factory.newXPath();
		URL url;
		try {
			url = new URL(URL + URLEncoder.encode(address + ", София", "UTF-8") + URL_SUFFIX);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.connect();
			
			InputSource geocoderResultInputSource = new InputSource(conn.getInputStream());
			Document geocoderResultDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(geocoderResultInputSource);
			conn.disconnect();
			NodeList nodes = (NodeList) xpath.evaluate("//result[1]//location/*",geocoderResultDocument, XPathConstants.NODESET);
			if(nodes.getLength() > 1){
				if(start)
				{
					startLat = Double.parseDouble(nodes.item(0).getTextContent());
					startLon = Double.parseDouble(nodes.item(1).getTextContent());
				}
				else
				{
					finishLat = Double.parseDouble(nodes.item(0).getTextContent());
					finishLon = Double.parseDouble(nodes.item(1).getTextContent());
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	public double getStartLat(){
		return startLat;
		
	}
	public double getStartLon(){
		return startLon;
		
	}
	public double getFinishLat(){
		return finishLat;
		
	}
	public double getFinishLon(){
		return finishLon;
		
	}
}
