/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.shared;

import java.io.Serializable;
import java.util.List;

public class TableInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6420157451707535684L;
	private String tableName;
	private int id;
	private List<ColumnInfo> columns;
	private boolean showInTabPanel;
	
	public TableInfo()
	{
		showInTabPanel = true;
	}
	
	public TableInfo(String tableName, int id, List<ColumnInfo> columns) {
		this.tableName = tableName;
		this.id = id;
		this.columns = columns;
		this.showInTabPanel = true;
	}
	
	public TableInfo(String tableName, int id, List<ColumnInfo> columns, boolean showInTabPanel) {
		this.tableName = tableName;
		this.id = id;
		this.columns = columns;
		this.showInTabPanel = showInTabPanel;

	}
	
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	

	public List<ColumnInfo> getColumns() {
		return columns;
	}

	public boolean showInTabPanel() {
		return showInTabPanel;
	}


}
