/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.shared;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class Record implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4796332045746851120L;
	private int id;
	private Map<Integer, String> fields; //Holds data for one field and the column id
	
	public Record()
	{
		fields = new HashMap<Integer, String>();
	}
	
	public Record(int id)
	{
		this();
		this.id = id;
	}
	
	public int getId()
	{
		return id;

	}
	
	public Set<Entry<Integer, String>> getFieldsEntrySet()
	{
		return fields.entrySet();
	}
	
	public void addField(int colId, String data)
	{
		fields.put(colId, data);
	}
	
	public String getValueById(int id)
	{
		return fields.get(id);
	}
}
