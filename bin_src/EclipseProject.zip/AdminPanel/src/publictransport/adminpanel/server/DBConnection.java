/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import publictransport.adminpanel.shared.DatabaseException;
/**
 * Handles Database Communication
 * @author Nikolay Dimitrov
 *
 */
public class DBConnection {
	private static DBConnection instance = null;
	private Connection con;
	
	
	private DBConnection(Properties config) throws ClassNotFoundException, SQLException
	{
		Class.forName(config.getProperty("dbDriver"));
		con = DriverManager.getConnection(config.getProperty("dbName"),
				config.getProperty("dbUser"),config.getProperty("dbPass"));
	}	
	
	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	public static DBConnection getInstance(Properties config) throws DatabaseException
	{
		if(instance == null) {
			try {
				instance = new DBConnection(config);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				throw new DatabaseException("MySQL driver is missing");

			} catch (SQLException e) {
				e.printStackTrace();
				throw new DatabaseException("SQL error");
			}
		}
		return instance;
	}
	
	public static void destroyConnection()
	{
		instance = null;
	}
	
	public ResultSet execQuery(String query, String... params) throws DatabaseException
	{
		try {
			PreparedStatement stmt = con.prepareStatement(query);
			int i = 1;
			for(String param: params)
			{
				stmt.setString(i, param);
				i++;
			}
			
			return stmt.executeQuery();
		} catch (SQLException e) {
			throw new DatabaseException("SQL error");
		}
	}
	
	public void execUpdate(String query, String... params) throws DatabaseException
	{
		try {
			PreparedStatement stmt = con.prepareStatement(query);
			int i = 1;
			for(String param: params)
			{
				stmt.setString(i, param);
				i++;
			}
			
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DatabaseException("SQL error");
		}
	}
	
}