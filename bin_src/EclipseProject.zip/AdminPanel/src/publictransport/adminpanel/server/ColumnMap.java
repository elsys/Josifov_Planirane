/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import publictransport.adminpanel.shared.ColumnInfo;
import publictransport.adminpanel.shared.IDataChecker;
import publictransport.adminpanel.shared.Record;
/**
 * Contains a map between column name and a id
 * @author Nikolay Dimitrov
 *
 */
public class ColumnMap {
	
	private List<ColumnInfo> detailedInfo; //Column info to send to the client
	private Map<Integer, String> columnNames; //For searching name by id
	private Map<String, Integer> reverseColumnNames; //For searching id by name

	public ColumnMap()
	{
		this.detailedInfo = new ArrayList<ColumnInfo>();
		this.columnNames = new HashMap<Integer, String>();
		this.reverseColumnNames = new HashMap<String, Integer>();
	}
	/**
	 * Gets column name by id
	 */
	public String getColNameById(int id)
	{
		return columnNames.get(id);
	}
	
	/**
	 * Get all the columns, comma separated(useful for SELECT queries);
	 * @return
	 */
	public String getCommaSeparatedColumns()
	{
		String res = "";
		boolean first = true;
		for(String columnName : columnNames.values())
		{
			if(first) first = false;
			else res += ",";
			res += columnName;
			
		}
		
		return res;
	}
	
	/**
	 * Get all the columns
	 */
	public Set<Entry<Integer, String>> getColumnsEntrySet()
	{
		return columnNames.entrySet();
	}
	
	/**
	 * Gets the id of a column by its name
	 */
	public Integer getColIdByName(String name)
	{
		return reverseColumnNames.get(name);
	}
	
	/**
	 * Gets the detailed column info to be send to the client
	 */
	public List<ColumnInfo> getColumnsInfo()
	{
		return detailedInfo;
	}

	/**
	 * Add a new column
	 * @param id Column id
	 * @param name Column Name
	 * @param dataChecker Validation class
	 */
	public void addColumn(int id, String name, IDataChecker dataChecker) {
		columnNames.put(id, name);
		reverseColumnNames.put(name, id);
		detailedInfo.add(new ColumnInfo(id, name, dataChecker));
	}
	
	/**
	 * Add a new column with foreign data
	 * @param id Column id
	 * @param name Column name
	 * @param foreignData Data in the foreign table
	 */
	public void addColumn(int id, String name, List<Record> foreignData) {
		columnNames.put(id, name);
		reverseColumnNames.put(name, id);
		detailedInfo.add(new ColumnInfo(id, name, foreignData));
	}

	/**
	 * Add a new column without validation
	 * @param id Column id
	 * @param name Column Name
	 */
	public void addColumn(int id, String name){
		columnNames.put(id, name);
		reverseColumnNames.put(name, id);
		detailedInfo.add(new ColumnInfo(id, name));
	}
}	

