/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.server;

import publictransport.adminpanel.shared.DatabaseException;
import publictransport.adminpanel.shared.DoubleChecker;
import publictransport.adminpanel.shared.IntegerChecker;
import publictransport.adminpanel.shared.StringChecker;

public class StopsTable extends BasicTable{

	private static final String ID_COLUMN_NAME = "idstop";
	private static final String TABLE_NAME = "Stops";
	private BasicTable providersTable;
	
	public StopsTable(DBConnection dbConnection, BasicTable providersTable){
		super(TABLE_NAME, ID_COLUMN_NAME, dbConnection);
		this.providersTable = providersTable;
		refreshColumns();
	}

	@Override
	public void refreshColumns() {
		ColumnMap columns = new ColumnMap();
		columns.addColumn(1, "name", new StringChecker(255));
		columns.addColumn(2, "latitude", new DoubleChecker());
		columns.addColumn(3, "longitude", new DoubleChecker());
		columns.addColumn(4, "webId", new IntegerChecker());
		try {
			columns.addColumn(5, "provider", providersTable.getAllRecords());
		} catch (DatabaseException e) {
			e.printStackTrace();
		}
		
		super.setColumnMap(columns);
		
	}



}
