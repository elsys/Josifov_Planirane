/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import publictransport.adminpanel.shared.ColumnInfo;
import publictransport.adminpanel.shared.DatabaseException;
import publictransport.adminpanel.shared.PagedResult;
import publictransport.adminpanel.shared.Record;
/**
 * Allows insert, update, delete, select on tables that don't require special handling
 * @author Nikolay Dimitrov
 *
 */
public abstract class BasicTable {
	private String tableName; //The name of the table in the database
	private ColumnMap columns; //The columns in this table
	private String idColumnName; //The id column name
	private String searchColumn; //Search in this column
	private DBConnection dbConnection;
	
	public BasicTable(String tableName, String idColumnName, DBConnection dbConnection) {
		this.tableName = tableName;
		this.setIdColumnName(idColumnName);
		this.setSearchColumn("name");
		this.setDbConnection(dbConnection);

	}

	public String getName()
	{
		return tableName;
	}
	/**
	 * Adds a record to the table
	 * @param record The record to add
	 */
	public void addRecord(Record record) throws DatabaseException {
		StringBuilder columnNames = new StringBuilder();
		StringBuilder values = new StringBuilder();
		
		boolean first = true;
		//Iterate through all the entries to be added
		for(Entry<Integer, String> entry : record.getFieldsEntrySet())
		{
			if(first) first = false;
			else
			{
				columnNames.append(",");
				values.append(",");
			}
			columnNames.append(columns.getColNameById(entry.getKey())); //Get each column name
			values.append("'");
			values.append(entry.getValue());
			values.append("'");
		}
		//Create the SQL query
		StringBuilder query = new StringBuilder("INSERT INTO ");
		query.append(getName());
		query.append(" (");
		query.append(columnNames);
		query.append(") VALUES (");
		query.append(values);
		query.append(")");
		//Execute the query
		getDbConnection().execUpdate(query.toString());
	}
	/**
	 * Deletes a record from the table
	 * @param record The record to delete(Only the id is required)
	 */
	public void deleteRecord(Record record) throws DatabaseException {
		//Create the SQL query
		StringBuilder query = new StringBuilder();
		query.append("DELETE FROM ");
		query.append(getName());
		query.append(" WHERE ");
		query.append(getIdColumnName());
		query.append("=");
		query.append(record.getId());
		
		//Execute the query
		getDbConnection().execUpdate(query.toString());
	}
	/**
	 * Updates a record in the table
	 * @param record The record to update
	 */
	public void updateRecord(Record record) throws DatabaseException
	{
		//Buider for creating the update query
		StringBuilder query = new StringBuilder("UPDATE ");
		query.append(getName());
		query.append(" SET ");
		
		boolean first = true;
		for(Entry<Integer, String> entry : record.getFieldsEntrySet())
		{
			if(first) first = false;
			else query.append(",");
			query.append(getColumns().getColNameById(entry.getKey()));
			query.append(" = '");
			query.append(entry.getValue());
			query.append("'");
		}
		
		query.append(" WHERE ");
		query.append(getIdColumnName());
		query.append( " = ");
		query.append(record.getId());
		//Execute the query
		getDbConnection().execUpdate(query.toString());
	}
	/**
	 * Get all records from table
	 */
	public List<Record> getAllRecords() throws DatabaseException {
		List<Record> records = new ArrayList<Record>();
		StringBuilder query=  new StringBuilder("SELECT "); //The builder for the query
		
		query.append(getIdColumnName());
		query.append(", ");
		query.append(getColumns().getCommaSeparatedColumns());
		query.append(" FROM ");
		query.append(getName());
		
		ResultSet resSet = getDbConnection().execQuery(query.toString());
		
		try {
			while(resSet.next()){//Iterate through all rows
				Record rec = new Record(resSet.getInt(getIdColumnName()));
				for(Entry<Integer, String> column : getColumns().getColumnsEntrySet())
				{
					String data = resSet.getString(column.getValue()); //Get the data for each column
					rec.addField(column.getKey(), data);//Save the data in the record
				}
				records.add(rec);
			}
		} catch (SQLException e) {
			throw new DatabaseException("SQL error");
		}
		return records;
	}
	/**
	 * Get column information
	 */
	public List<ColumnInfo> getColumnsInfo() {
		return getColumns().getColumnsInfo();
	}

	public void setColumnMap(ColumnMap columns) {
		this.setColumns(columns);
		
	}


	/**
	 * Search for records in the table and return them
	 * @param offset Begin from offset
	 * @param limit Maximum number of records
	 * @param searchStr what to search
	 * @return The query result with the offset and total number of records in the table
	 * @throws DatabaseException
	 */
	public PagedResult getRecords(int offset, int limit, String searchStr) throws DatabaseException {
		List<Record> records = new ArrayList<Record>();
		
		if(searchStr == null)
		{
			searchStr = "";
		}
		
		StringBuilder query = new StringBuilder("SELECT SQL_CALC_FOUND_ROWS "); //The SQL query
		query.append(getIdColumnName());
		query.append(", ");
		query.append(getColumns().getCommaSeparatedColumns());
		query.append(" FROM ");
		query.append(getName());
		query.append(" WHERE ");
		query.append(getSearchColumn());
		query.append(" LIKE '%");
		query.append(searchStr);
		query.append("%'");
		if(limit > 0){
			query.append(" LIMIT ");
			query.append(offset);
			query.append(",");
			query.append(limit);
		}
		
		ResultSet resSet = getDbConnection().execQuery(query.toString());
		
		try {
			while(resSet.next()){//Iterate through all rows
				Record rec = new Record(resSet.getInt(getIdColumnName()));
				for(Entry<Integer, String> column : getColumns().getColumnsEntrySet())
				{
					String data = resSet.getString(column.getValue()); //Get the data for each column
					rec.addField(column.getKey(), data); //Save the data in the record
				}
				records.add(rec);
			}
		} catch (SQLException e) {
			throw new DatabaseException("SQL error");
		}
		int totalCount  = 0;
		resSet = getDbConnection().execQuery("SELECT FOUND_ROWS()");//Get the number of records without the limit
		try {
			resSet.next();
			totalCount = resSet.getInt(1);
		} catch (SQLException e) {
			throw new DatabaseException("SQL error");
		}
		return new PagedResult(records, offset, totalCount);
	}


	public void setSearchColumn(String searchColumn) {
		this.searchColumn = searchColumn;
		
	}


	public void setIdColumnName(String idColumnName) {
		this.idColumnName = idColumnName;
	}


	public String getIdColumnName() {
		return idColumnName;
	}


	public void setColumns(ColumnMap columns) {
		this.columns = columns;
	}


	public ColumnMap getColumns() {
		return columns;
	}

	public String getSearchColumn() {
		return searchColumn;
	}
	/**
	 * Forces an refresh on column information, used to refresh foreign data
	 */
	abstract public void refreshColumns();

	private void setDbConnection(DBConnection dbConnection) {
		this.dbConnection = dbConnection;
	}

	protected DBConnection getDbConnection() {
		return dbConnection;
	}
}
