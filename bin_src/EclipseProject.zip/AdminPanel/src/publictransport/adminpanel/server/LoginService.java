/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.server;

import java.security.SecureRandom;
import java.sql.ResultSet;
import java.util.Properties;

import javax.servlet.ServletException;

import publictransport.adminpanel.client.ILoginService;
import publictransport.adminpanel.shared.DatabaseException;
import tools.ConfigurationLoader;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;


public class LoginService extends RemoteServiceServlet implements ILoginService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7216273776975660971L;
	private DBConnection dbConnection;

	@Override
	public void init() throws ServletException {		
		Properties properties = new ConfigurationLoader(getServletContext()).getConfiguration();
		try {
			dbConnection = DBConnection.getInstance(properties);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
	}
	private String generateSession()
	{
		SecureRandom random = new SecureRandom();
		return random.generateSeed(32).toString();
		
	}
	@Override
	public String checkLogin(String username, String password) throws DatabaseException {
		try {
			ResultSet usernameSet = dbConnection.execQuery("SELECT paramValue FROM Configuration WHERE paramName = 'username' AND paramValue = ?", username);
			boolean isUsernameCorrect = usernameSet.first();
			ResultSet passwordSet = dbConnection.execQuery("SELECT paramValue FROM Configuration WHERE paramName = 'password' AND paramValue = MD5(?)", password);
			if(isUsernameCorrect && passwordSet.first()){
				String session = generateSession();
				getServletContext().setAttribute("sessionID", session);
				return session;
			}
			else return null;
		} catch (Exception e) {
			e.printStackTrace();
			throw new DatabaseException();
		}
		
	}

	@Override
	public boolean isSessionValid(String session) {
		if (getServletContext().getAttribute("sessionID") == null) return false;
		return session.compareTo(getServletContext().getAttribute("sessionID").toString()) == 0;
	}

	@Override
	public boolean updatePassword(String session, String password, String oldPassword) {
		if(isSessionValid(session))
		{
			ResultSet passwordSet;
			try {
				passwordSet = dbConnection.execQuery("SELECT paramValue FROM Configuration WHERE paramName = 'password' AND paramValue = MD5('"+ oldPassword + "')");
				if(passwordSet.first()){
					dbConnection.execUpdate("UPDATE Configuration SET paramValue = MD5('"+ password + "') WHERE paramName = 'password'");
					return true;
				}
				else return false;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		} return false;

		
	}

}
