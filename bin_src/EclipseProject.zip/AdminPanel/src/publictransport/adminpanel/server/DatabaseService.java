/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.server;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;

import javax.servlet.ServletException;

import publictransport.adminpanel.client.IDatabaseService;
import publictransport.adminpanel.shared.Configuration;
import publictransport.adminpanel.shared.DatabaseException;
import publictransport.adminpanel.shared.PagedResult;
import publictransport.adminpanel.shared.Record;
import publictransport.adminpanel.shared.Status;
import publictransport.adminpanel.shared.TableInfo;
import tools.ConfigurationLoader;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
/**
 * Receive calls from the interface and dispatches them to right BasicTable implementation based on tableId;
 * @author Nikolay Dimitrov
 *
 */
public class DatabaseService extends RemoteServiceServlet implements
		IDatabaseService {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8517285633281697270L;
	private Map<Integer, BasicTable> tables;//Map between table id and the table class
	
	@Override
	public void init() throws ServletException {
		DBConnection dbConnection;
		
		Properties properties = new ConfigurationLoader(getServletContext()).getConfiguration();
		try {
			dbConnection = DBConnection.getInstance(properties);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
		
		tables = new HashMap<Integer, BasicTable>();

		BasicTable providers = new ProvidersTable(dbConnection);
		tables.put(Configuration.PROVIDERS_TABLE_ID, providers);

		BasicTable transportTypes = new TransportTypesTable(dbConnection);
		tables.put(Configuration.TRANSPORT_TYPES_TABLE_ID, transportTypes);

		BasicTable transports = new TransportsTable(dbConnection, providers, transportTypes);
		tables.put(Configuration.TRANSPORTS_TABLE_ID, transports);

		BasicTable stops = new StopsTable(dbConnection, providers);
		tables.put(Configuration.STOPS_TABLE_ID, stops);

		BasicTable connections = new ConnectionsTable(dbConnection);
		tables.put(Configuration.CONNECTIONS_TABLE_ID, connections);

		super.init();
	}

	/**
	 * Checks sessions and adds a record
	 */
	@Override
	public Status addRecord(String session, int tableId, Record record) {
		if (checkSession(session)) {
			try {
				tables.get(tableId).addRecord(record); //Finds the appropriate table in the map and dispatches the call
				forceRefresh(); //Refresh the foreign data of all tables
				return new Status(true, "OK");
			} catch (DatabaseException e) {
				e.printStackTrace();
				return new Status(false,
						"Database error. See server log for more information");
			}
		}
		return new Status(false, "Invalid login data");
	}
	/**
	 * Checks the session
	 * @param session The client session
	 * @return true on valid session
	 */
	private boolean checkSession(String session) {
		//Check if session exists and it is the same as the client one
		if (getServletContext().getAttribute("sessionID") == null) return false;
		return session.compareTo(getServletContext().getAttribute("sessionID").toString()) == 0;
	}

	/**
	 * Checks session and deletes a record
	 */
	@Override
	public Status deleteRecord(String session, int tableId, Record record) {
		if (checkSession(session)) {
			try {
				//Finds the appropriate table in the map and dispatches the call
				tables.get(tableId).deleteRecord(record);
				forceRefresh(); //Refresh the foreign data of all tables
				return new Status(true, "OK");
			} catch (DatabaseException e) {
				e.printStackTrace();
				return new Status(false,
						"Database error. Probably there is data referencing the row you're trying to delete. See server log for more information");
			}
		}
		return new Status(false, "Invalid login data");
	}
	
	/**
	 * Checks session and updates a record
	 */
	@Override
	public Status updateRecord(String session, int tableId, Record record)
			throws DatabaseException {
		if (checkSession(session)) {
			try {
				//Finds the appropriate table in the map and dispatches the call
				tables.get(tableId).updateRecord(record);
				forceRefresh(); //Refresh the foreign data of all tables
				return new Status(true, "OK");
			} catch (DatabaseException e) {
				e.printStackTrace();
				return new Status(false,
						"Database error. See server log for more information");
			}
		}
		return new Status(false, "Invalid login data");
	}

	/**
	 * Gets all the records
	 */
	@Override
	public List<Record> getAllRecords(String session, int tableId)
			throws DatabaseException {
		if(checkSession(session)) return tables.get(tableId).getAllRecords();
		else return null;
	}

	/**
	 * Gets table information
	 */
	@Override
	public List<TableInfo> getTables(String session) {
		if(checkSession(session))
		{
			List<TableInfo> result = new ArrayList<TableInfo>();
	
			//Add each table information to result
			for (Entry<Integer, BasicTable> e : tables.entrySet()) {
				if (e.getKey() == Configuration.CONNECTIONS_TABLE_ID) //Don't show the connections table in the tabs
					result.add(new TableInfo(e.getValue().getName(), e.getKey(), e
							.getValue().getColumnsInfo(), false));
				else
					result.add(new TableInfo(e.getValue().getName(), e.getKey(), e
							.getValue().getColumnsInfo()));
			}
			return result;
		}
		else return null;
	}
	/**
	 * Get records between offset and offset + limit. Supports search too
	 */
	@Override
	public PagedResult getRecords(String session, int tableId,
			String searchStr, int offset, int limit) throws DatabaseException {
		if(checkSession(session)) return tables.get(tableId).getRecords(offset, limit, searchStr);
		else return null;
	}

	/**
	 * Forces refresh on all columns
	 */
	private void forceRefresh()
	{
		for (Entry<Integer, BasicTable> e : tables.entrySet()) {
			e.getValue().refreshColumns();
		}
	}
}
