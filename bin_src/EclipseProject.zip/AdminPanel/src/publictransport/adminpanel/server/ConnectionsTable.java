/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import publictransport.adminpanel.shared.Configuration;
import publictransport.adminpanel.shared.DatabaseException;
import publictransport.adminpanel.shared.PagedResult;
import publictransport.adminpanel.shared.Record;

public class ConnectionsTable extends BasicTable {

	private static final String ID_COLUMN_NAME = "idConnection";
	private static final String TABLE_NAME = "Connections";

	public ConnectionsTable(DBConnection dbConnection) {
		super(TABLE_NAME, ID_COLUMN_NAME, dbConnection);
		refreshColumns();
		
		super.setSearchColumn("line");

	}
	
	public PagedResult getRecords(int offset, int limit, String searchStr) throws DatabaseException {
		List<Record> records = new ArrayList<Record>();
		
		if(searchStr == null)
		{
			searchStr = "";
		}
		
		StringBuilder query = new StringBuilder("SELECT SQL_CALC_FOUND_ROWS ");
		query.append(getIdColumnName());
		query.append(", s1.name AS origName, s2.name AS destName, travelTime  FROM ");
		query.append(getName());
		query.append(" INNER JOIN Stops AS s1 ON s1.idStop = origStop INNER JOIN Stops AS s2 on s2.idStop = destStop "); 
		query.append(" WHERE ");
		query.append( getSearchColumn());
		query.append(" LIKE '%");
		query.append(searchStr);
		query.append("%' ORDER BY ");
		query.append(getIdColumnName());
		if(limit > 0){
			query.append(" LIMIT ");
			query.append(offset);
			query.append(",");
			query.append(limit);
		}
		System.err.println(query);
		ResultSet resSet = getDbConnection().execQuery(query.toString());
		
		try {
			while(resSet.next()){
				Record rec = new Record(resSet.getInt(getIdColumnName()));
				for(Entry<Integer, String> column : getColumns().getColumnsEntrySet())
				{
					String data = resSet.getString(column.getValue());
					rec.addField(column.getKey(), data);
				}
				records.add(rec);
			}
		} catch (SQLException e) {
			throw new DatabaseException("SQL error");
		}
		int totalCount  = 0;
		resSet = getDbConnection().execQuery("SELECT FOUND_ROWS()");
		try {
			resSet.next();
			totalCount = resSet.getInt(1);
		} catch (SQLException e) {
			throw new DatabaseException("SQL error");
		}
		return new PagedResult(records, offset, totalCount);
	}

	@Override
	public void refreshColumns() {
		ColumnMap columns = new ColumnMap();
		columns.addColumn(1, "origName");
		columns.addColumn(2, "destName");
		columns.addColumn(Configuration.TRAVEL_TIME_COLUMN_ID, "travelTime");
		
		super.setColumnMap(columns);
		
	}

	@Override
	public void addRecord(Record record) throws DatabaseException {
		int dest;
		//Retrieve line, origStop and dest Stop for this record
		StringBuilder selectQuery = new StringBuilder("SELECT destStop FROM ");
		selectQuery.append(getName());
		selectQuery.append(" WHERE ");
		selectQuery.append(getIdColumnName());
		selectQuery.append("=");
		selectQuery.append(record.getValueById(Configuration.PREV_CONNECTION_COLUMN_ID));
		ResultSet resSet = getDbConnection().execQuery(selectQuery.toString());
		System.err.println(selectQuery.toString());

		try {
			resSet.next();
			dest = resSet.getInt("destStop");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DatabaseException();
		}
		
		StringBuilder updateQuery = new StringBuilder("UPDATE ");
		updateQuery.append(getName());
		updateQuery.append(" SET ");
		updateQuery.append("destStop = '");
		updateQuery.append(record.getValueById(Configuration.NEXT_STOP_COLUMN_ID));
		updateQuery.append("' WHERE ");
		updateQuery.append(getIdColumnName());
		updateQuery.append("=");
		updateQuery.append(record.getValueById(Configuration.PREV_CONNECTION_COLUMN_ID));
		//Execute the query
		System.err.println(updateQuery);
		getDbConnection().execUpdate(updateQuery.toString());
		
		
		//Create the SQL query
		StringBuilder insertQuery = new StringBuilder("INSERT INTO ");
		insertQuery.append(getName());
		insertQuery.append(" (origStop, destStop, travelTime, line) VALUES('");
		insertQuery.append(record.getValueById(Configuration.NEXT_STOP_COLUMN_ID));
		insertQuery.append("','");
		insertQuery.append(dest);
		insertQuery.append("','");
		insertQuery.append(record.getValueById(Configuration.TRAVEL_TIME_COLUMN_ID));
		insertQuery.append("','");
		insertQuery.append(record.getValueById(Configuration.LINE_COLUMN_ID));
		insertQuery.append("')");
		System.err.println(insertQuery);
		//Execute the query
		getDbConnection().execUpdate(insertQuery.toString());
		
	}

	@Override
	public void deleteRecord(Record record) throws DatabaseException {
		int dest,orig, line;
		//Retrieve line, origStop and dest Stop for this record
		StringBuilder selectQuery = new StringBuilder("SELECT line, origStop, destStop FROM ");
		selectQuery.append(getName());
		selectQuery.append(" WHERE ");
		selectQuery.append(getIdColumnName());
		selectQuery.append("=");
		selectQuery.append(record.getId());
		ResultSet resSet = getDbConnection().execQuery(selectQuery.toString());

		try {
			resSet.next();
			orig = resSet.getInt("origStop");
			dest = resSet.getInt("destStop");
			line = resSet.getInt("line");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DatabaseException();
		}
		
		StringBuilder updateQuery = new StringBuilder("UPDATE ");
		updateQuery.append(getName());
		updateQuery.append(" SET ");
		updateQuery.append("destStop = '");
		updateQuery.append(dest);
		updateQuery.append("' WHERE line = '");
		updateQuery.append(line);
		updateQuery.append("' AND destStop = '");
		updateQuery.append(orig);
		updateQuery.append("'");
		//Execute the query
		getDbConnection().execUpdate(updateQuery.toString());
		
		
		//Create the SQL query
		StringBuilder deleteQuery = new StringBuilder();
		deleteQuery.append("DELETE FROM ");
		deleteQuery.append(getName());
		deleteQuery.append(" WHERE ");
		deleteQuery.append(getIdColumnName());
		deleteQuery.append("=");
		deleteQuery.append(record.getId());
		
		//Execute the query
		getDbConnection().execUpdate(deleteQuery.toString());
	}

	@Override
	public void updateRecord(Record record) throws DatabaseException {
		//Buider for creating the update query
		StringBuilder query = new StringBuilder("UPDATE ");
		query.append(getName());
		query.append(" SET ");
		query.append("travelTime = '");
		query.append(record.getValueById(Configuration.TRAVEL_TIME_COLUMN_ID));
		query.append("' WHERE ");
		query.append(getIdColumnName());
		query.append( " = ");
		query.append(record.getId());
		//Execute the query
		getDbConnection().execUpdate(query.toString());
	
	}


}
