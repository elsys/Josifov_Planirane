/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;

import publictransport.adminpanel.shared.PagedResult;
import publictransport.adminpanel.shared.Record;
import publictransport.adminpanel.shared.Status;

import com.extjs.gxt.ui.client.data.PagingLoadResult;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Handles communication with the backend
 * @author Nikolay Dimitrov
 *
 */
public class BackendCommunicator {
	private int tableId; //The table id to send with each query
	private final IDatabaseServiceAsync databaseService; //The GWT service
	private final String session; //The authentication session
	
	public BackendCommunicator(String session, int tableId, IDatabaseServiceAsync databaseService) 
	{
		this.databaseService = databaseService;
		this.tableId = tableId;
		this.session = session;
	}
	void addRecord(Record record, final IStatusReceiver recv)
	{
		databaseService.addRecord(session, tableId, record, new AsyncCallback<Status>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert("Error on add, see log for more information");
			}

			@Override
			public void onSuccess(Status status) {
				recv.receiveResult(status);
			}
			
		});
	}
	void deleteRecord(Record record, final IStatusReceiver recv)
	{
		databaseService.deleteRecord(session, tableId, record, new AsyncCallback<Status>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert("Error on delete, see log for more information");
			}
			

			@Override
			public void onSuccess(Status status) {
				recv.receiveResult(status);
			}
			
		});
	}
	void updateRecord(Record record, final IStatusReceiver recv)
	{
		databaseService.updateRecord(session, tableId, record, new AsyncCallback<Status>(){

			@Override
			public void onFailure(Throwable caught) {
				Window.alert("Error on update, see log for more information");
			}

			@Override
			public void onSuccess(Status status) {
				recv.receiveResult(status);
			}
			
		});
	}
	
	public void getRecords(String searchString, final int offset, int limit,final AsyncCallback<PagingLoadResult<RecordStore>> callback) {
		databaseService.getRecords(session, tableId, searchString, offset, limit, new AsyncCallback<PagedResult>() {
			
			@Override
			public void onSuccess(PagedResult result) {
				//Convert the data so that PageLoader can understand it
				RecordCallbackAdapter adapter = new RecordCallbackAdapter(result);
				callback.onSuccess(adapter.getPagingLoadResult()); 
				
			}
			
			@Override
			public void onFailure(Throwable caught) {
				callback.onFailure(caught);
			}
		});
		
	}
}
