/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;

import java.util.ArrayList;
import java.util.List;

import publictransport.adminpanel.shared.ColumnInfo;
import publictransport.adminpanel.shared.Configuration;
import publictransport.adminpanel.shared.Record;
import publictransport.adminpanel.shared.Status;
import publictransport.adminpanel.shared.TableInfo;

import com.extjs.gxt.ui.client.data.BasePagingLoader;
import com.extjs.gxt.ui.client.data.LoadEvent;
import com.extjs.gxt.ui.client.data.Loader;
import com.extjs.gxt.ui.client.data.ModelData;
import com.extjs.gxt.ui.client.data.PagingLoadConfig;
import com.extjs.gxt.ui.client.data.PagingLoadResult;
import com.extjs.gxt.ui.client.data.RpcProxy;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.KeyListener;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.HorizontalPanel;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.ComboBox;
import com.extjs.gxt.ui.client.widget.form.Field;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.form.Validator;
import com.extjs.gxt.ui.client.widget.form.ComboBox.TriggerAction;
import com.extjs.gxt.ui.client.widget.grid.CellEditor;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
/**
 * A table for editing route
 * @author Nikolay Dimitrov
 *
 */
public class RouteEditor extends EditableTable{
	private final BackendCommunicator stopsComm; //Gets new stops from server
	private LayoutContainer addContainer; //Container for add fields
	private ListStore<RecordStore> stopsStore; //Stores the stops dropdown
	private int idLine; //The line we are editinig
 	private BasePagingLoader<PagingLoadResult<ModelData>> stopsLoader;
	private ComboBox<RecordStore> newStopCombo; //The combo box for new stop
	
	public RouteEditor (int idLine, BackendCommunicator connectionsComm, BackendCommunicator stopsComm, TableInfo connectionsTableInfo)
	{
		super(connectionsComm, connectionsTableInfo, null);
		this.stopsComm = stopsComm;
		this.idLine = idLine;
		setLayout(new RowLayout());
	}
	/**
	 * Creates the loader for the data in the table
	 */
	@Override
	protected void createLoader() {
		RpcProxy<PagingLoadResult<RecordStore>> proxy = new RpcProxy<PagingLoadResult<RecordStore>>() {
			@Override
			protected void load(Object loadConfig,
					AsyncCallback<PagingLoadResult<RecordStore>> callback) {		
				PagingLoadConfig config = (PagingLoadConfig) loadConfig;
				//Uses the search to send the lineID to the server
				String searchStr = (config.get("search") != null) ? config.get("search").toString(): "";
				getDbComm().getRecords(searchStr, config.getOffset(), config.getLimit(), callback);
			}
		};

		setLoader(new BasePagingLoader<PagingLoadResult<ModelData>>(proxy));
		getLoader().setRemoteSort(true);
		//Sets the line in the search field
		getLoader().addListener(Loader.BeforeLoad, new Listener<LoadEvent>() {
			public void handleEvent(LoadEvent be) {
				be.<ModelData> getConfig().set("search", idLine);
			}
		});
	}

	/**
	 * Creates a store for storing the stops in the newStop dropdown
	 */
	private void createStopsStore() {
		RpcProxy<PagingLoadResult<RecordStore>> proxy = new RpcProxy<PagingLoadResult<RecordStore>>() {
			@Override
			//Gets all the stops from the server
			protected void load(Object loadConfig,
					AsyncCallback<PagingLoadResult<RecordStore>> callback) {		
				PagingLoadConfig config = (PagingLoadConfig) loadConfig;
				String searchStr = (config.get("search") != null) ? config.get("search").toString(): "";
				stopsComm.getRecords(searchStr, 0, 10, callback);
			}
		};

		stopsLoader = new BasePagingLoader<PagingLoadResult<ModelData>>(proxy);
		stopsLoader.setRemoteSort(true);
		//Before sending a new query to the server, add search information from the combobx
		stopsLoader.addListener(Loader.BeforeLoad, new Listener<LoadEvent>() {
			public void handleEvent(LoadEvent be) {
				be.<ModelData> getConfig().set("search", newStopCombo.getRawValue());
			}
		});
		
		stopsStore = new ListStore<RecordStore>(stopsLoader);
	}
	
	/**
	 * Creates the panel that allows adding a new stop to the route
	 */
	@Override
	protected void createAddPanel() {
		addContainer = new HorizontalPanel(); 
		
		final ComboBox<RecordStore> prevCombo = generatePrevCombo();
		addContainer.add(prevCombo);
		
		createStopsStore();
		//Creates the combobox for selecting the new stop;
		generateNewStopCombo();
    
	     //Travel time info
	    final TextField<String> travelField = new TextField<String>();
	    travelField.setEmptyText("Travel Time");
	    addContainer.add(travelField);
	    //When the add button is clicked
	    addContainer.add(new Button("Add", new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce) {
				//Creates a new record with all the new information
				Record rec = new Record();
				rec.addField(Configuration.PREV_CONNECTION_COLUMN_ID, prevCombo.getValue().get("id").toString()); //ID of the prev stop
				rec.addField(Configuration.NEXT_STOP_COLUMN_ID, newStopCombo.getValue().get("id").toString());//ID of the new stop
				rec.addField(Configuration.TRAVEL_TIME_COLUMN_ID, travelField.getValue());//The travel time
				rec.addField(Configuration.LINE_COLUMN_ID, String.valueOf(idLine));
				getDbComm().addRecord(rec, new IStatusReceiver() {
					
					@Override
					public void receiveResult(Status status) {
						if(status.isSuccessful())
						{
							loadContent(); //Refresh on success
						}
						else Window.alert("Error on insert" + status.getStatusMessage());
					}
				});
			}
		}));
	    
		add(addContainer, new RowData(1, -1, new Margins(5)));
		
	}
	/**
	 * Creates a drop-down that allows selecting a new stop to be added
	 */
	private void generateNewStopCombo() {
		newStopCombo = new ComboBox<RecordStore>();
	    newStopCombo.setEmptyText("Name"); 
		newStopCombo.setTriggerAction(TriggerAction.ALL);  
		newStopCombo.setDisplayField("1");
		newStopCombo.setStore(stopsStore);
		//When the text is edited, get the new stop list from the server
		newStopCombo.addKeyListener(new KeyListener(){

			@Override
			public void componentKeyUp(ComponentEvent event) {
				stopsLoader.load();
			}
			
		});
	    addContainer.add(newStopCombo);
	}
	/**
	 * Creates a combobox containing all the stops in this route
	 * @return
	 */
	private ComboBox<RecordStore> generatePrevCombo() {
		final ComboBox<RecordStore> prevCombo = new ComboBox<RecordStore>();  
		prevCombo.setEmptyText("After stop");
		prevCombo.setForceSelection(true);  
		prevCombo.setTriggerAction(TriggerAction.ALL);  
		prevCombo.setDisplayField("1");
		prevCombo.setStore(getStore());
		return prevCombo;
	}
	

	
	@Override
	protected ColumnModel generateColumnModel(TableInfo tableInfo) {
		List<ColumnConfig> configs = new ArrayList<ColumnConfig>();  
		
		
		//Adds the id column
		ColumnConfig idColumn = new ColumnConfig();
		idColumn.setId("id");
		idColumn.setHeader("Id");
		idColumn.setWidth(100);
		configs.add(idColumn);
		
		
		//Adds all the other columns
		for(final ColumnInfo info :tableInfo.getColumns())
		{
			ColumnConfig column = new ColumnConfig();  
			column.setId(String.valueOf(info.getId()));
			column.setHeader(info.getName());
			column.setWidth(100);
			
			if(info.getId() == Configuration.TRAVEL_TIME_COLUMN_ID)
			{
				//Update text field
				TextField<String> text = new TextField<String>();  
				text.setAllowBlank(false);  
				column.setEditor(new CellEditor(text)); 
			}
		

			configs.add(column);
		}
		generateRemoveButton(configs);

		
		return new ColumnModel(configs);
	}
	/**
	 * Don't show a search panel
	 */
	@Override
	protected void createSearchPanel()
	{
		
	}
	
}
