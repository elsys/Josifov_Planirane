/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import publictransport.adminpanel.shared.Record;

import com.extjs.gxt.ui.client.data.BaseModelData;

/**
 * This class stores data about a Record in EXT GWT format 
 * @author Nikolay Dimitrov
 *
 */
public class RecordStore extends BaseModelData{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5968189561447099430L;
	List<Integer> ids;
	public RecordStore(Record rec) {
		ids = new ArrayList<Integer>();
		
		setId(rec.getId());
		
		//Add all fields to the parent class
		for(Entry<Integer, String> entry : rec.getFieldsEntrySet())
		{
			ids.add(entry.getKey());
			setIndexedProperty(entry.getKey(), entry.getValue());
		}
	}

	public void setId(int id){
		set("id", id);
	}
	
	public int getId(){
		return get("id");
	}
	
	public void setIndexedProperty(int index, String value)
	{
		set(String.valueOf(index), value);
	}
	
	public String getIndexedProperty(int index)
	{
		return get(String.valueOf(index));
	}
	
	/**
	 * Generates a Record from the stored data
	 * @return
	 */
	public Record getRecord()
	{
		Record rec = new Record(getId());
		for(Integer id: ids)
		{
			rec.addField(id, getIndexedProperty(id));
		}
		return rec;
	}
}
