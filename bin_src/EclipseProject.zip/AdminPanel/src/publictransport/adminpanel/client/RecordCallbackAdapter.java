/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;

import java.util.ArrayList;
import java.util.List;

import publictransport.adminpanel.shared.PagedResult;
import publictransport.adminpanel.shared.Record;

import com.extjs.gxt.ui.client.data.BasePagingLoadResult;
import com.extjs.gxt.ui.client.data.PagingLoadResult;
/**
 * Converts between publictransport.adminpanel.shared PagegResult class and EXT GWT class
 * @author Nikolay Dimitrov
 *
 */
public class RecordCallbackAdapter {


	private PagedResult result;

	public RecordCallbackAdapter(PagedResult result) {
		this.result = result;
	}

	public PagingLoadResult<RecordStore> getPagingLoadResult() {
		List<RecordStore> recordStores = new ArrayList<RecordStore>();
		//Add each field to the new record type
		for(Record rec: result.getRecords())
		{
			recordStores.add(new RecordStore(rec));
		}
		PagingLoadResult<RecordStore> recordStoreResult = new BasePagingLoadResult<RecordStore>(recordStores, result.getOffset(), result.getTotalCount());
		return recordStoreResult;
	}



}
