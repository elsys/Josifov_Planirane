/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;

import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.layout.FormLayout;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * A simple form, allows editing of password
 * @author Nikolay Dimitrov
 *
 */
public class PasswordEditor extends LayoutContainer {

	private ILoginServiceAsync loginService;
	private String session; //Session is required to update password
	
	public PasswordEditor(ILoginServiceAsync newLoginService, String newSession) {
		this.loginService = newLoginService;
		this.session = newSession;
		
		setLayout(new FormLayout());
		
		final TextField<String> passwordBox = new TextField<String>();
		passwordBox.setPassword(true);
		passwordBox.setFieldLabel("New Password");
		passwordBox.setWidth(500);
		add(passwordBox);

		final TextField<String> confirmBox = new TextField<String>();
		confirmBox.setPassword(true);
		confirmBox.setFieldLabel("Confirm");
		confirmBox.setWidth(500);
		add(confirmBox);
		
		final TextField<String> oldPassBox = new TextField<String>();
		oldPassBox.setPassword(true);
		oldPassBox.setFieldLabel("Old Password");
		oldPassBox.setWidth(500);
		add(oldPassBox);
		
		generateSubmitButton(passwordBox, confirmBox, oldPassBox);
		
	
	}

	private void generateSubmitButton(final TextField<String> passwordBox,
			final TextField<String> confirmBox,
			final TextField<String> oldPassBox) {
		Button clickBox = new Button("Change", new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce) {
				//Get the values of the fields
				String password = (passwordBox.getValue() != null) ? passwordBox.getValue() : "";
				String confirm = (confirmBox.getValue() != null) ? confirmBox.getValue() : "";
				String oldPassword = (oldPassBox.getValue() != null) ? oldPassBox.getValue() : "";
				
				//If the new password and the confirmation are equel and the password is more than 3 symbols
				if(password.compareTo(confirm) == 0 && password.length() > 3) 	{
					loginService.updatePassword(session, password, oldPassword, new AsyncCallback<Boolean>() {
						@Override
						public void onSuccess(Boolean result) {
							if(result)	{
								Window.alert("Password changed");
								passwordBox.clear();
								confirmBox.clear();
								oldPassBox.clear();
							}
							else Window.alert("Wrong old password");
						}
						@Override
						public void onFailure(Throwable caught) {
							Window.alert("Try again later");
						}
					});
				}
				else if(password.length() <= 3) Window.alert("Passwords should be at least 4 characters");
				else Window.alert("Passwords don't match");
			}
		});
		add(clickBox);
	}

}
