/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;

import java.util.List;

import publictransport.adminpanel.shared.Configuration;
import publictransport.adminpanel.shared.TableInfo;

import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.widget.TabItem;
import com.extjs.gxt.ui.client.widget.TabPanel;
import com.extjs.gxt.ui.client.widget.Viewport;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.RootPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 * This class handles login and display tabs on the top
 */
/**
 * @author Nikolay Dimitrov
 *
 */
public class AdminPanel implements EntryPoint, IRouteEditHandler {

	private static final String COOKIE_NAME = "sessionID";
	private TabPanel tabPanel; //The tab panel on the top
	private TableInfo connectionsTableInfo; //Used when creating RouteEditor objects
	private final IDatabaseServiceAsync databaseService = GWT
			.create(IDatabaseService.class); //Database async serivce
	private final ILoginServiceAsync loginService = GWT
			.create(ILoginService.class); //Login async service
	private Viewport v; //Main view
	private String sessionId; //Remembers the ssesion;

	public AdminPanel() {
		v = new Viewport();
		v.setLayout(new FitLayout());

		RootPanel.get("TabPanelContainer").add(v);
	}

	/**
	 * Check is the session is valid
	 * @param session The session  to check
	 */
	private void checkSession(final String session) {
		loginService.isSessionValid(session, new AsyncCallback<Boolean>() {

			@Override
			public void onSuccess(Boolean result) {
				if (result) {
					sessionId = session; //Remember the session id
					requestTables();
				} else
					showLoginBox(); //If the session is invalid, show login box
			}

			@Override
			public void onFailure(Throwable caught) {
				Window.alert("Please, try again later");
			}
		});
	}
	/**
	 * Native JavaScript for reloading
	 */
	private native void reload() /*-{ 
    $wnd.location.reload(); 
   }-*/; 
	
	/**
	 * Show Login Form with username and password
	 */
	private void showLoginBox() {
		FormPanel cp = new FormPanel();

		// for the username
		final TextField<String> usernameBox = new TextField<String>();
		usernameBox.setFieldLabel("Username");
		usernameBox.setWidth(500);
		cp.add(usernameBox);
		//for the password
		final TextField<String> passwordBox = new TextField<String>();
		passwordBox.setPassword(true);
		passwordBox.setFieldLabel("Password");
		passwordBox.setWidth(500);
		cp.add(passwordBox);

		//Login button
		Button loginButton = new Button("Login",
				new SelectionListener<ButtonEvent>() {
					@Override
					public void componentSelected(ButtonEvent ce) {
						loginService.checkLogin(usernameBox.getValue(),
								passwordBox.getValue(),
								new AsyncCallback<String>() {

									@Override
									public void onSuccess(String result) {
										if (result != null) {
											sessionId = result; //Save the session
											Cookies.setCookie(COOKIE_NAME, sessionId);//Rember login until the browser is restarted
											requestTables();
										} else
											Window.alert("Wrong password");
									}

									@Override
									public void onFailure(Throwable caught) {
										Window.alert("Server error. See log for more information");
									}
								});
					}
				});
		cp.add(loginButton);
		v.add(cp);
		v.layout();
	}
	/**
	 * Request the tables from the server
	 */
	private void requestTables() {
		v.removeAll();
		tabPanel = new TabPanel();
		v.add(tabPanel);
		v.layout();
		databaseService.getTables(sessionId,
				new AsyncCallback<List<TableInfo>>() {

					@Override
					public void onSuccess(List<TableInfo> tables) {
						receiveTables(tables);
					}

					@Override
					public void onFailure(Throwable caught) {
						Window.alert("Backend error. See server log for more information");
					}
				});
	}

	private void receiveTables(List<TableInfo> tablesInfo) {
		for (TableInfo tableInfo : tablesInfo) {
			//Remember the table info for the connections table
			if (tableInfo.getId() == Configuration.CONNECTIONS_TABLE_ID) {
				connectionsTableInfo = tableInfo;
			}
			if (tableInfo.showInTabPanel()) {
				//Create a dbComm for handling communication with the databse
				BackendCommunicator dbComm = new BackendCommunicator(sessionId,
						tableInfo.getId(), databaseService);
				final EditableTable table = new EditableTable(dbComm,
						tableInfo, this);

				TabItem item = new TabItem(tableInfo.getTableName());

				Viewport v = new Viewport();
				v.setLayout(new FitLayout());
				v.add(table);

				item.add(v);
				//When the tab is selected, load the data from server
				item.addListener(Events.Select, new Listener<ComponentEvent>() {

					@Override
					public void handleEvent(ComponentEvent be) {
						table.loadContent();
					}

				});

				tabPanel.add(item);
			}
		}
		addPasswordEditTab();
		addLogoutTab();
	}

	/**
	 * Tab for editing password 
	 **/
	private void addPasswordEditTab() {
		TabItem item = new TabItem("Change Password");
		
		
		Viewport v = new Viewport();
		v.setLayout(new FitLayout());
		v.add(new PasswordEditor(loginService, sessionId));
		
		item.add(v);
		
		tabPanel.add(item);
	}

	/**
	 * Empty tab for logout
	 */
	private void addLogoutTab() {
		TabItem item = new TabItem("Logout");
		//When selected, logout the user from the system
		item.addListener(Events.Select, new Listener<ComponentEvent>() {

			@Override
			public void handleEvent(ComponentEvent be) {
				Cookies.removeCookie(COOKIE_NAME);
				reload();
			}

		});
		tabPanel.add(item);
	}

	/**
	 * This is the entry point method.
	 * Checks if the session in the cookie is valid or displays the login window if the cookie doesn't exist
	 */
	public void onModuleLoad() {
		String session = Cookies.getCookie(COOKIE_NAME);
		if (session != null)
			checkSession(session);
		else
			showLoginBox();
	}

	/**
	 * This function is called when the Edit Route button is clicked
	 * It adds a new tab with a RouteEditor
	 */
	@Override
	public void editRoute(int id, String name) {
		TabItem item = new TabItem("Route for: " + name);
		final RouteEditor editor = new RouteEditor(id,
				new BackendCommunicator(sessionId,
						Configuration.CONNECTIONS_TABLE_ID, databaseService),
				new BackendCommunicator(sessionId, Configuration.STOPS_TABLE_ID,
						databaseService), connectionsTableInfo);

		Viewport v = new Viewport();
		v.setLayout(new FitLayout());
		v.add(editor);

		item.add(v);
		item.setClosable(true);
		//Lazy loading, load content when tab is clicked
		item.addListener(Events.Select, new Listener<ComponentEvent>() {

			@Override
			public void handleEvent(ComponentEvent be) {
				editor.loadContent();
			}

		});

		//Insert before logout and edit password tabs
		tabPanel.insert(item, tabPanel.getItemCount() - 2);
		tabPanel.setSelection(item);//Focus on this tab

	}
}
