
/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;

import java.util.ArrayList;
import java.util.List;

import publictransport.adminpanel.shared.ColumnInfo;
import publictransport.adminpanel.shared.Configuration;
import publictransport.adminpanel.shared.Record;
import publictransport.adminpanel.shared.Status;
import publictransport.adminpanel.shared.TableInfo;

import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.data.BasePagingLoader;
import com.extjs.gxt.ui.client.data.LoadEvent;
import com.extjs.gxt.ui.client.data.Loader;
import com.extjs.gxt.ui.client.data.ModelData;
import com.extjs.gxt.ui.client.data.PagingLoadConfig;
import com.extjs.gxt.ui.client.data.PagingLoadResult;
import com.extjs.gxt.ui.client.data.RpcProxy;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.ComponentEvent;
import com.extjs.gxt.ui.client.event.KeyListener;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.store.Store;
import com.extjs.gxt.ui.client.store.StoreEvent;
import com.extjs.gxt.ui.client.store.Record.RecordUpdate;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.HorizontalPanel;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.ComboBox;
import com.extjs.gxt.ui.client.widget.form.Field;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.form.Validator;
import com.extjs.gxt.ui.client.widget.form.ComboBox.TriggerAction;
import com.extjs.gxt.ui.client.widget.grid.CellEditor;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnData;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.grid.EditorGrid;
import com.extjs.gxt.ui.client.widget.grid.Grid;
import com.extjs.gxt.ui.client.widget.grid.GridCellRenderer;
import com.extjs.gxt.ui.client.widget.grid.RowEditor;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.extjs.gxt.ui.client.widget.toolbar.PagingToolBar;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Table, that allows editing of database values
 * @author Nikolay Dimitrov
 *
 */
public class EditableTable extends LayoutContainer{
	private final BackendCommunicator dbComm;
	private IRouteEditHandler routeHandler; //Which class to call when Edit Route is clicked
	
	private TableInfo tableInfo; //Table information
	private ListStore<RecordStore> store; //The data that is contained in the table

	private EditorGrid<RecordStore> grid; //The table itself
	private ContentPanel contentPanel; //Table container
	private RowEditor<RecordStore> rowEditor; //Displayed when you click on a row
	private PagingToolBar toolBar; //The toolbar that show pages
	private BasePagingLoader<PagingLoadResult<ModelData>> loader; //Loads data when the page is changed
	private LayoutContainer addContainer; //Container for add fields
	private TextField<String> searchBox; 
	private List<IAddField> addFields; //Used to iterate through all the add fields
	
	public EditableTable(BackendCommunicator dbComm, TableInfo tableInfo, IRouteEditHandler routeHandler)
	{
		this.dbComm = dbComm;
		this.tableInfo = tableInfo;
		this.routeHandler = routeHandler;
		
		setLayout(new RowLayout());
		this.addFields = new ArrayList<IAddField>();
	}
	protected ListStore<RecordStore> getStore() {
		return store;
	}
	/**
	 * Add listeners for various events
	 */
	private void addEventListeners() {
		store.addListener(Store.Update, new Listener<StoreEvent<RecordStore>>() {
			public void handleEvent(StoreEvent<RecordStore> be) {
				//When a row has been edited
				if(be.getOperation() == RecordUpdate.EDIT)
				{
					
					dbComm.updateRecord(be.getModel().getRecord(), new IStatusReceiver() {
						@Override
						public void receiveResult(Status status) {
							if(status.isSuccessful())
							{
								store.commitChanges(); //If everything is ok, update the local storage
							}
							else
							{
								Window.alert("Error on update:" + status.getStatusMessage());
							}
						}
					});
				}
			}
		});
	}
	/**
	 * Display everything when rendered
	 */
	@Override  
	protected void onRender(Element parent, int index) {  
		  super.onRender(parent, index);
		  
		  createPagingToolbar();
		  createAddPanel();
		  createSearchPanel();
		  createContentPanel();
		  createTable();
	 }
	
	/**
	 * Creates the panel, containing information for adding data
	 */
	protected void createAddPanel() {
		addContainer = new HorizontalPanel(); 
		add(addContainer, new RowData(1, -1, new Margins(5)));
		
	}
	/**
	 * Creates the search panel and the search box
	 */
	protected void createSearchPanel() {
		LayoutContainer searchContainer = new HorizontalPanel(); 
		
		searchBox = new TextField<String>();
		searchBox.setEmptyText("Search");
		searchBox.setWidth(500);

		//Send search on every keypress
		searchBox.addKeyListener(new KeyListener(){

			@Override
			public void componentKeyUp(ComponentEvent event) {
				loadContent();
			}
		});
		searchContainer.add(searchBox);
		add(searchContainer, new RowData(1, -1, new Margins(5)));
	}
	public void loadContent()
	{
		getLoader().load();
		getLoader().setOffset(0); //Load from the first row initially
	}
	
	/**
	 * Toolbar that shows the page
	 */
	protected void createPagingToolbar()
	{
		createLoader();
	
		toolBar = new PagingToolBar(50);  
		toolBar.bind(getLoader());  
		
		store = new ListStore<RecordStore>(getLoader());
		addEventListeners();
	}
	/**
	 * Creates the loader for loading new data when the page is cahnged
	 */
	protected void createLoader() {
		RpcProxy<PagingLoadResult<RecordStore>> proxy = new RpcProxy<PagingLoadResult<RecordStore>>() {
			@Override
			protected void load(Object loadConfig,
					AsyncCallback<PagingLoadResult<RecordStore>> callback) {		
				PagingLoadConfig config = (PagingLoadConfig) loadConfig;
				//Get only the records containg the information from the search box
				String searchStr = (config.get("search") != null) ? config.get("search").toString(): "";
				//Sends the query with the current search data, offset and limit
				getDbComm().getRecords(searchStr, config.getOffset(), config.getLimit(), callback);
			}
		};

		setLoader(new BasePagingLoader<PagingLoadResult<ModelData>>(proxy));
		getLoader().setRemoteSort(true);
		//Before loading new data, set the search property in the configuration to the text in the search box
		getLoader().addListener(Loader.BeforeLoad, new Listener<LoadEvent>() {
			public void handleEvent(LoadEvent be) {
				be.<ModelData> getConfig().set("search", searchBox.getValue());
			}
		});
	}
	
	/**
	 *  Create the tables itself
	 */
	private void createTable() {
		ColumnModel cm = generateColumnModel(tableInfo);
		
		rowEditor = new RowEditor<RecordStore>();  
		
		grid = new EditorGrid<RecordStore>(store, cm); 
		grid.setAutoExpandColumn("1"); //Expand the column after the id
		grid.addPlugin(rowEditor); //Editor, displayed when user click on a row
		contentPanel.add(grid);

	}
	/**
	 * Creates the container of everything
	 */
	private void createContentPanel() {
		contentPanel = new ContentPanel();  
		contentPanel.setButtonAlign(HorizontalAlignment.CENTER);  
	    contentPanel.setLayout(new FitLayout());
	    contentPanel.setHeaderVisible(false);
	    contentPanel.setBottomComponent(toolBar); 
		add(contentPanel, new RowData(1, 0.98, new Margins(5))); //Leave some space between elements
	}
	
	/**
	 * Generates the information about the columns
	 * @param tableInfo Information about the table
	 * @return column information
	 */
	protected ColumnModel generateColumnModel(TableInfo tableInfo) {
		List<ColumnConfig> configs = new ArrayList<ColumnConfig>(); //Config for each column
		
		
		//Adds the id column
		ColumnConfig idColumn = new ColumnConfig();
		idColumn.setId("id");
		idColumn.setHeader("Id");
		idColumn.setWidth(100);
		configs.add(idColumn);
		
		
		//Adds all the other columns
		for(final ColumnInfo info :tableInfo.getColumns())
		{
			ColumnConfig column = new ColumnConfig();  
			column.setId(String.valueOf(info.getId()));
			column.setHeader(info.getName());
			column.setWidth(100);
			
			//Add a drop-down menu for foreign keys selection
			if(info.isForeign()){
			    generateForeignColumns(info, column); 
			}
			else
			{
				generateColumns(info, column);
			}
			configs.add(column);
		}
		generateAddButton();
		//Generate the remove and route button
		generateRouteEditButton(configs);
		generateRemoveButton(configs);

		
		return new ColumnModel(configs);
	}
	/**
	 * Generates the add button after the add fields
	 */
	private void generateAddButton() {
		addContainer.add(new Button("Add", new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce)
			{
				Record rec = new Record();
				for(IAddField addField : addFields)
				{
					//Validate all fields
					if(!addField.isValid() || addField.getFieldValue() == null)
					{
						Window.alert("Information is not valid!");
						return;
					}
					//Add them to a record object
					rec.addField(addField.getFieldId(), addField.getFieldValue());
				}
				dbComm.addRecord(rec, new IStatusReceiver() {	
					@Override
					public void receiveResult(Status status) {
						loadContent();	//Refresh on success
					}
				});
			}
		}));
	}
	
	/**
	 * Creates the fields for add and update for every non-foreign column
	 */
	private void generateColumns(final ColumnInfo info, ColumnConfig column) {
		//Update text field
		TextField<String> text = new TextField<String>();  
		text.setAllowBlank(false);  
		//Data validation
		text.setValidator(new Validator() {
			
			@Override
			public String validate(Field<?> field, String value) {
				if(info.getChecker().isValid(value)) return null;
				else return "Data input is invalid";
			}
		});
		column.setEditor(new CellEditor(text)); 
		
		//Add text field
		final TextField<String> addField = new TextField<String>();
		addField.setEmptyText(info.getName());
		
		//Data validation
		addField.setValidator(new Validator() {
			@Override
			public String validate(Field<?> field, String value) {
				if(info.getChecker().isValid(value)) return null;
				else return "Data input is invalid";
			}
		});
		addContainer.add(addField);
		addFields.add(new IAddField() {
			@Override
			public String getFieldValue() {
				return addField.getValue();
			}
			@Override
			public int getFieldId() {
				return info.getId();
			}
			@Override
			public boolean isValid() {
				return addField.isValid();
			}
		});
	}
	/**
	 * Creates a button for editing the route of a line
	 * @param configs
	 */
 	private void generateRouteEditButton(List<ColumnConfig> configs) {
 		if(tableInfo.getId() == Configuration.TRANSPORTS_TABLE_ID)//If this the Lines table
 		{
			ColumnConfig column = new ColumnConfig();
			column.setHeader("Change route");
			column.setId("route");
			column.setWidth(100);
			
			GridCellRenderer<RecordStore>  renderer = new GridCellRenderer<RecordStore>() { 
				@Override
				public Object render(RecordStore model, String property,
						ColumnData config, final int rowIndex, int colIndex,
						final ListStore<RecordStore> store, Grid<RecordStore> grid) 
				{
					Button b = new Button("Edit route",
							new SelectionListener<ButtonEvent>() {
								@Override
								public void componentSelected(ButtonEvent ce) {
									routeHandler.editRoute(Integer.parseInt(store.getAt(rowIndex).get("id").toString()), store.getAt(rowIndex).get("1").toString() );
								}
							});
					return b;
				}  
			    };  
			column.setRenderer(renderer);
			configs.add(column);	
 		}
		
	}
 	/**
 	 * Create a Delete button
 	 */
	protected void generateRemoveButton(List<ColumnConfig> configs) {
		ColumnConfig column = new ColumnConfig();  
		column.setHeader("Delete");
		column.setId("del");
		column.setWidth(100);
		
		GridCellRenderer<RecordStore> renderer = new GridCellRenderer<RecordStore>() { 
			@Override
			public Object render(final RecordStore model, String property,
					ColumnData config, int rowIndex, int colIndex,
					ListStore<RecordStore> storeLoc, Grid<RecordStore> grid) {
				//Create the button
				Button delButton = new Button("Delete", new SelectionListener<ButtonEvent>() {
					@Override
					public void componentSelected(ButtonEvent ce) {
						dbComm.deleteRecord(model.getRecord(), new IStatusReceiver() {
							@Override
							public void receiveResult(Status status) {
								if(status.isSuccessful())
								{
									//Refresh if delete is succesfull
									loadContent();
								}
								else
								{
									Window.alert("Error on delete:" + status.getStatusMessage());
								}
							}
						});
					}
				});
				return delButton;
			}  
		    };  
		column.setRenderer(renderer);
		
		configs.add(column);
	
	}
	/**
	 * Creates a dropdown for every foreign column
	 */
	private void generateForeignColumns(final ColumnInfo info, ColumnConfig column) 
	{
		final ListStore<RecordStore> rs = new ListStore<RecordStore>(); //Store, containing the information from the foreign table
		for(Record elem : info.getForeignData())
		{
			rs.add(new RecordStore(elem)); //Store the data in the store
		}
		
		GridCellRenderer<RecordStore> renderer = new GridCellRenderer<RecordStore>() { 
			//When this column is displayed, show the names from the foreign table
			@Override
			public Object render(RecordStore model, String property,
					ColumnData config, int rowIndex, int colIndex,
					ListStore<RecordStore> store, Grid<RecordStore> grid) {
				int id = Integer.parseInt((String) model.get(property));
				return rs.findModel("id", id).get(String.valueOf(Configuration.FOREIGN_KEY_NAME_FIELD_ID));
			}  
		    };  
		column.setRenderer(renderer);
		//Editor is displayed when the row is clicked
		CellEditor editor = generateForeignCellEditor(rs);
		column.setEditor(editor);
		
		generateAddCombo(info, rs);
	}
	/**
	 * Editor when the row is clicked
	 */
	private CellEditor generateForeignCellEditor(final ListStore<RecordStore> rs) {
		final ComboBox<RecordStore> combo = new ComboBox<RecordStore>();  
		combo.setForceSelection(true);  
		combo.setTriggerAction(TriggerAction.ALL);  
		//Display the "name" column of the foreign table in the drop down
		combo.setDisplayField(String.valueOf(Configuration.FOREIGN_KEY_NAME_FIELD_ID));
		combo.setStore(rs); 
		CellEditor editor = new CellEditor(combo){
			@Override  
		      public Object preProcessValue(Object value) {  
				return rs.findModel("id", Integer.parseInt(value.toString()));
		      }  
		    @Override  
		    public Object postProcessValue(Object value) {  
		      if (value == null) {  
		        return value;  
		      }  
		      return ((ModelData) value).get("id").toString();  
		    }  
		       
   
		};
		return editor;
	}
	/**
	 * Create a combo box for foreign data in the add container
	 */
	private void generateAddCombo(final ColumnInfo info,
			final ListStore<RecordStore> rs) {
		final ComboBox<RecordStore> addCombo = new ComboBox<RecordStore>();  
		addCombo.setEmptyText(info.getName());
		addCombo.setForceSelection(true);  
		addCombo.setTriggerAction(TriggerAction.ALL);  
		//Display the "name" column in the drop down
		addCombo.setDisplayField(String.valueOf(Configuration.FOREIGN_KEY_NAME_FIELD_ID));
		addCombo.setStore(rs);
		//Add to the add fields list, so we can access the data when the add button is clicked
		addFields.add(new IAddField() {
			@Override
			public String getFieldValue() {
				return addCombo.getValue().get("id").toString();
			}
			@Override
			public int getFieldId() {
				return info.getId();
			}
			@Override
			public boolean isValid() {
				return addCombo.isValid();
			}
		});
		addContainer.add(addCombo);
	}
	public BackendCommunicator getDbComm() {
		return dbComm;
	}
	public void setLoader(BasePagingLoader<PagingLoadResult<ModelData>> loader) {
		this.loader = loader;
	}
	public BasePagingLoader<PagingLoadResult<ModelData>> getLoader() {
		return loader;
	}
}
