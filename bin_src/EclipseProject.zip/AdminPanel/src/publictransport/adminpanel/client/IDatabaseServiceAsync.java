/** 
 *  Copyright (C) 2010  Nikolay Dimitrov
 *  
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * */
package publictransport.adminpanel.client;
import java.util.List;

import publictransport.adminpanel.shared.PagedResult;
import publictransport.adminpanel.shared.Record;
import publictransport.adminpanel.shared.Status;
import publictransport.adminpanel.shared.TableInfo;

import com.google.gwt.user.client.rpc.AsyncCallback;
public interface IDatabaseServiceAsync {
	void addRecord(String session, int tableId, Record record, AsyncCallback<Status> callback);
	void deleteRecord(String session, int tableId, Record record, AsyncCallback<Status> callback);
	void updateRecord(String session, int tableId, Record record, AsyncCallback<Status> callback);
	void getAllRecords(String session, int tableId, AsyncCallback<List<Record>> callback);
	void getRecords(String session, int tableId, String searchStr, int offset, int limit,  AsyncCallback<PagedResult> callback);
	void getTables(String session, AsyncCallback<List<TableInfo>> callback);
}
